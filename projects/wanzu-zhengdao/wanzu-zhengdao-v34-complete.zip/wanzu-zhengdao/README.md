# 万族争道 — V34 山海路引

[回到技能库根目录](../../README.md)

修仙生活经营 + 像素地图 + 文字 CRPG，运行入口为 [`index.html`](index.html)。游戏可以单文件离线游玩，原有文字游戏、战斗试炼及经营系统保持在内。

## 运行与开发

- 直接使用浏览器打开 `index.html`。iPhone 请优先在升级前导出 `WZ27:` 存档码。
- 重新构建：`python scripts/build_v34.py`；静态检查：`python scripts/verify.py`。
- 在开发工具中使用当前仓库已有的 Agent Skills（[`router`](../../router/SKILL.md)）以及本项目 [`AGENTS.md`](AGENTS.md)。此项目是原生 Canvas 2D，自研引擎，不应套用 Phaser/Godot API。
- `baseline/V33.html` 为旧版基线，`source/V34_pixel_module.js` 是 V34 模块。
- 需要 Node.js 22.20+ 时，可在仓库根目录依上游 README 安装技能；游戏本身无需这些依赖。

## 许可证与公开提醒

这个目录是独立的《万族争道》游戏项目。根目录 Agent Skills 的 Apache-2.0 许可不代表本游戏原创角色、美术和内容自动获得相同的再许可；其授权信息见 [`GAME_CONTENT_NOTICE.md`](GAME_CONTENT_NOTICE.md)。不要提交任何玩家存档码、令牌或个人数据。

## 质量限制

Chrome/Chromium 回归测试不等于 iPhone Safari 实机长期稳定性。

> 本发布包按 `projects/wanzu-zhengdao/` 路径准备。现有 GitHub 集成尝试创建文件和分支均返回 403，因此尚未自动推送。
