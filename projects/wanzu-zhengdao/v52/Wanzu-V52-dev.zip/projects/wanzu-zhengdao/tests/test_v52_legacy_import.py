import os
from pathlib import Path
from playwright.sync_api import sync_playwright

root = Path(__file__).resolve().parents[1]
with sync_playwright() as pw:
    browser = pw.chromium.launch(channel=os.getenv('WANZU_BROWSER_CHANNEL'))
    # Export from the actual pre-chapter release using its own save encoder.
    old = browser.new_page(offline=True)
    old.goto((root / 'baseline/V45.html').as_uri(), wait_until='commit')
    old.wait_for_function('Boolean(window.V41)')
    old.evaluate("""() => {
        const s = V41.getState();
        Object.assign(s,{day:15,area:'river',tool:'hand',x:6,y:4,face:'right',riverChoices:[1,2,2,0]});
        V41.debugState(s);
    }""")
    code = old.evaluate('V41.saveCode()')
    old.close()
    for file, stage, scene in [('baseline/V51.html','bell-dawn','循声见灯'), ('index.html','start','桥灯照浅滩')]:
        page = browser.new_page(offline=True, has_touch=True, viewport={'width':320,'height':568})
        page.goto((root / file).as_uri(), wait_until='commit')
        page.get_by_role('button',name='进入自由修行',exact=True).tap()
        page.evaluate("""() => localStorage.setItem('wanzu_ferry_prologue_v1','bell-dawn')""")
        page.locator('.v42-more summary').tap()
        page.locator('.v42-more [data-do=saves]').tap()
        page.locator('[data-do=import]').tap()
        page.locator('#v27-import').fill(code)
        page.locator('[data-do=importConfirm]').tap()
        assert page.evaluate('V51.restorePoints().length') > 0
        page.reload(wait_until='commit')
        page.get_by_role('button',name='继续自由修行').tap()
        state = page.evaluate('V51.getState()')
        assert (state['ferryStage'],state['riverChoices']) == (stage,[1,2,2,0])
        page.get_by_role('button',name='交互',exact=True).tap()
        assert scene in page.get_by_role('dialog').inner_text()
        page.close()
    browser.close()
