from pathlib import Path

root = Path(__file__).resolve().parents[1]
page = (root / 'baseline/V51.html').read_text()
changes = [
    ('function validated(x){', 'function validated(x, {imported = false} = {}){'),
    ("(Object.hasOwn(x,'ferryStage') ? 'start' : legacyFerryStage())", "(imported || Object.hasOwn(x,'ferryStage') ? 'start' : legacyFerryStage())"),
    ('validated(JSON.parse(new TextDecoder().decode(bytes)))', 'validated(JSON.parse(new TextDecoder().decode(bytes)), {imported:true})'),
    ('V46 起会一并恢复渡口剧情。', '含渡口篇章的存档会恢复到原章节。早期存档从渡口第一夜开头进入，已选的四季回信照常保留。'),
    ('window.V51=window.V50', 'window.V52=window.V51=window.V50'),
]
for old, new in changes:
    assert page.count(old) == 1, old
    page = page.replace(old, new)
(root / 'index.html').write_text(page)
