import os
from pathlib import Path
from playwright.sync_api import sync_playwright

root = Path(__file__).resolve().parents[1]
with sync_playwright() as pw:
    browser = pw.chromium.launch(channel=os.getenv('WANZU_BROWSER_CHANNEL'))
    for width,height in [(320,568),(375,667),(390,844)]:
        for file, fixed in [('baseline/V54.html',False),('index.html',True)]:
            page = browser.new_page(offline=True,has_touch=True,viewport={'width':width,'height':height})
            page.goto((root/file).as_uri(),wait_until='commit')
            page.get_by_role('button',name='进入自由修行',exact=True).tap()
            page.evaluate("()=>{const s=V54.getState();s.mode='dungeon';s.day=7;V54.debugState(s)}")
            panel=page.get_by_role('dialog')
            def tap(label):
                page.get_by_role('button',name=label,exact=True).tap()
            tap('本季来信')
            assert ('旧渠只够灌一畦' in panel.inner_text()) == fixed
            assert panel.locator('[data-do^="riverReply:"]').count()==0
            if fixed:
                home=panel.get_by_role('button',name='回洞府写回信')
                assert home.evaluate('b=>{const r=b.getBoundingClientRect();return r.top>=0 && r.bottom<=innerHeight && b.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2))}')
                home.tap()
                tap('继续征战')
                assert page.evaluate('V55.getState().mode')=='dungeon'
                tap('本季来信')
                home.tap()
                tap('撤回洞府')
                assert page.evaluate('V55.getState().day')==7
                assert panel.locator('[data-do^="riverReply:"]').count()==2
                tap('给山民种止血草')
                assert page.evaluate('V55.getState().riverChoices')==[2,0,0,0]
            page.close()
    browser.close()
