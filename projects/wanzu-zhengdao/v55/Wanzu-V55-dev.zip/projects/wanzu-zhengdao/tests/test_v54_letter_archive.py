import os
from pathlib import Path
from playwright.sync_api import sync_playwright

root = Path(__file__).resolve().parents[1]
with sync_playwright() as pw:
    browser = pw.chromium.launch(channel=os.getenv('WANZU_BROWSER_CHANNEL'),
                                 executable_path=os.getenv('WANZU_BROWSER_PATH'))
    for filename, fixed in [('baseline/V53.html', False), ('index.html', True)]:
        for choice, phrase in [(1, '替病中的阿婆'), (2, '一把小锄头')]:
            page = browser.new_page(offline=True, has_touch=True, viewport={'width':320,'height':568})
            page.goto((root / filename).as_uri())
            page.get_by_role('button', name='进入自由修行', exact=True).tap()
            panel = page.get_by_role('dialog')
            def day(number):
                page.evaluate('(d)=>{const s=V53.getState();s.day=d;V53.debugState(s)}', number)
            def read(archive=False):
                page.get_by_role('button', name='本季来信', exact=True).or_(
                    page.get_by_role('button', name='本季回信', exact=True)).tap()
                if archive:
                    panel.locator('summary').tap()
                return panel.inner_text()
            def close():
                panel.get_by_role('button',name='收起信册').tap()
            day(51)  # First winter reply in the second year.
            read()
            panel.locator('[data-do^="riverReply:"]').nth(choice-1).tap()
            close()
            assert phrase not in read(True)
            close()
            day(57)
            assert phrase in read()
            close()
            day(64)
            assert (phrase in read(True)) == fixed
            close()
            if fixed:
                # Actual archive from an older build may lack the new field.
                page.evaluate('()=>{const s=V53.getState();delete s.winterReplyDay;V53.debugState(s);V53.save()}')
                page.reload()
                page.get_by_role('button', name='继续自由修行').tap()
                assert page.evaluate('V53.getState().winterReplyDay') == 51
                day(78)
                assert phrase in read(True)
            page.close()
    browser.close()
print('PASS V53 archive regression and V54 both outcomes after rollover and reload')
