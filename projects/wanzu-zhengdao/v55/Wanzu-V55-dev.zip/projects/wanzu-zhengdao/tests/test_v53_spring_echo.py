import os
from pathlib import Path
from playwright.sync_api import sync_playwright

root = Path(__file__).resolve().parents[1]
with sync_playwright() as pw:
    browser = pw.chromium.launch(channel=os.getenv('WANZU_BROWSER_CHANNEL'))
    for width,height in [(320,568),(375,667),(390,844)]:
        for winter, expected in [(1,'替病中的阿婆应了一声'),(2,'在木牌背面画了一把小锄头')]:
            page = browser.new_page(offline=True,has_touch=True,viewport={'width':width,'height':height})
            page.goto((root/'index.html').as_uri(),wait_until='commit')
            page.get_by_role('button',name='进入自由修行',exact=True).tap()
            panel = page.get_by_role('dialog')
            def open_letter():
                page.get_by_role('button',name='本季来信',exact=True).tap()
            open_letter()
            assert '木牌上的春信' not in panel.inner_text()
            panel.get_by_role('button',name='收起信册').tap()
            page.evaluate('()=>{const s=V53.getState(); s.day=28; V53.debugState(s)}')
            open_letter()
            panel.locator('[data-do^="riverReply:"]').nth(winter-1).tap()
            panel.get_by_role('button',name='收起信册').tap()
            page.evaluate('()=>{const s=V53.getState(); s.day=29; V53.debugState(s)}')
            open_letter()
            assert expected in panel.inner_text()
            buttons=panel.locator('[data-do^="riverReply:"]')
            assert buttons.count()==2
            for button in buttons.all():
                assert button.evaluate("""b=>{const r=b.getBoundingClientRect();
                    return r.top>=0 && r.bottom<=innerHeight && b.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2))}""")
            buttons.first.tap()
            assert expected in panel.inner_text()
            page.reload(wait_until='commit')
            page.get_by_role('button',name='继续自由修行').tap()
            page.get_by_role('button',name='本季回信',exact=True).tap()
            assert expected in panel.inner_text()
            assert page.evaluate('V53.getState().riverChoices')==[1,0,0,winter]
            page.close()
