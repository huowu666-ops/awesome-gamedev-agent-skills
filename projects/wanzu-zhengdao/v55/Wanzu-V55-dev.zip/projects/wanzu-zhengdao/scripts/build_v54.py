from pathlib import Path

root = Path(__file__).resolve().parents[1]
page = (root / 'baseline/V53.html').read_text()

def replace(before, after):
    global page
    assert page.count(before) == 1, before
    page = page.replace(before, after)

replace('riverChoices:[0,0,0,0],meals:', 'riverChoices:[0,0,0,0],winterReplyDay:0,meals:')
replace(' a.npcCareDay=Object.fromEntries', """ a.winterReplyDay=0;
 if(a.riverChoices[3] && a.day>=22){
  const validDay=d=>Number.isInteger(d) && d>=22 && d<=a.day && (d-1)%28>=21;
  let d=x.winterReplyDay;
  if(!validDay(d)){
   const record=a.notes.find(n=>/^第[0-9]+日 · 封河之夜：/.test(n));
   d=record && Number(record.slice(1,record.indexOf('日')));
  }
  // Older saves without a dated note can only establish the most recent possible winter.
  a.winterReplyDay=validDay(d)?d:Math.min(a.day,28*Math.floor((a.day+6)/28));
 }
 a.npcCareDay=Object.fromEntries""")
replace('  s.riverChoices[i]=pick;', '  s.riverChoices[i]=pick;\n  if(i===3)s.winterReplyDay=s.day;')
replace("if (day <= 28) return '';", "if (!state.winterReplyDay || Math.floor((day-1)/28)<=Math.floor((state.winterReplyDay-1)/28)) return '';")
replace('i===0 && current===0 ? springPlaqueEcho','i===0 ? springPlaqueEcho')
replace('window.V53=window.V52','window.V54=window.V53=window.V52')
(root / 'index.html').write_text(page)
