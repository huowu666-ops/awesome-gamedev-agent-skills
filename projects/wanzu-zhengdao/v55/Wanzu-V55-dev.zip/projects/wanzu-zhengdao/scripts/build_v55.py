from pathlib import Path

root = Path(__file__).resolve().parents[1]
page = (root / 'baseline/V54.html').read_text()
def edit(old, new):
    global page
    assert page.count(old) == 1, old
    page = page.replace(old, new)

edit("else if(season===letter.season && state.mode==='farm'){", "else if(season===letter.season){")
edit("""body=(previous?""", """const response=state.mode==='farm'
    ? letter.choices.map((label,j)=>makeButton(label,'riverReply:'+i+':'+(j+1))).join('')
    : makeButton('回洞府写回信','retreatForLetter');
   body=(previous?""")
edit("""'<p>'+autumnRequest(letter)+'</p><div class="v40-buttons">'+letter.choices.map((label,j)=>makeButton(label,'riverReply:'+i+':'+(j+1))).join('')+'</div>';""","""'<p>'+autumnRequest(letter)+'</p><div class="v40-buttons">'+response+'</div>';""")
edit("function retreat(){if(state.mode", "function retreat(forLetter=false){if(state.mode")
edit("label:'撤回洞府',on:'doRetreat',primary:true", "label:'撤回洞府',on:forLetter?'doRetreatForLetter':'doRetreat',primary:true")
edit("function doRetreat(){const ok=change", "function doRetreat(forLetter=false){if(state.mode!=='dungeon')return;const ok=change")
edit("携所获之物回到九曜灵圃。';});if(ok){modal=null;tab='farm';render();}", "携所获之物回到九曜灵圃。';});if(ok){modal=null;tab='farm';render();if(forLetter)riverLetterBook();}")
edit("if(action==='riverLetters')return riverLetterBook();","if(action==='riverLetters')return riverLetterBook();\n if(action==='retreatForLetter')return retreat(true);\n if(action==='doRetreatForLetter')return doRetreat(true);")
edit("window.V54=window.V53","window.V55=window.V54=window.V53")
(root/'index.html').write_text(page)
