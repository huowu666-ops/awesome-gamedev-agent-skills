from pathlib import Path

root = Path(__file__).resolve().parents[1]
page = (root / 'baseline/V52.html').read_text()
anchor = 'function riverLetterBook(){'
helper = """function springPlaqueEcho(day, winterChoice) {
 if (day <= 28) return '';
 if (winterChoice === 1) return '<p>木牌上的春信 · 沈禾照着墨羽刻的名字送秧苗。念到最后一家，门里的孩子替病中的阿婆应了一声。</p>';
 if (winterChoice === 2) return '<p>木牌上的春信 · 去年按手印的孩子又长高了，在木牌背面画了一把小锄头。沈禾认出他的笔迹，给他留了一株苗。</p>';
 return '';
}
"""
old = "return '<article class=\"v40-person\"><b>'+letter.season+' · '+letter.title+'　'+letter.author+'</b>'+body+'</article>';"
new = """const springEcho = i===0 && current===0 ? springPlaqueEcho(state.day,state.riverChoices[3]) : '';
  """ + old.replace("+'</b>'+body", "+'</b>'+springEcho+body")
for before, after in [(anchor, helper + anchor), (old, new), ('window.V52=window.V51','window.V53=window.V52=window.V51')]:
    assert page.count(before) == 1, before
    page = page.replace(before, after)
(root / 'index.html').write_text(page)
