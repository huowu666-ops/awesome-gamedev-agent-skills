// The boat must actually have reached shore for the village to remember it.
function firstNightMarker() {
 switch (state.ferryStage) {
  case 'bell-home': case 'bell-dawn': return 1;
  case 'lamp-home': case 'lamp-dawn': return 2;
  default: return 0;
 }
}
function bridgeMarker() {
 return state.riverChoices[2] || firstNightMarker();
}
function autumnRequest(letter) {
 if (letter.season !== '秋') return letter.text;
 const marker = firstNightMarker();
 if (marker === 1) return '铁柏把旧钟绳搁在膝上：“隔雾能听出岸在哪儿，靠岸却还看不清台阶。今年再铸一口钟，还是添盏灯？”';
 if (marker === 2) return '铁柏摘下灯罩擦净烟灰：“看见灯，船就近了；雾厚的时候，他们还得摸索半程。今年添钟，还是再打一盏灯？”';
 return letter.text;
}
function visitBridgeMarker() {
 const marker = firstNightMarker();
 if (!marker) return riverLetterBook();
 const autumn = state.riverChoices[2];
 const scenes = marker === 1 ? [
  ['渡口试声','那孩子把耳朵贴在桥柱上。对岸敲了两声，他便往沙上划两道线，记下今日来船。'],
  ['两岸应钟','新钟挂在对岸，旧钟留在桥头。孩子敲一下，那边便回一下。两条船约好在河心错身，雾天也不用抢渡。'],
  ['循声见灯','船夫循旧钟过弯，看见新灯才收桨。孩子把晾在石阶上的湿鞋拎开，给第一位夜客让出落脚处。']
 ] : [
  ['灯下候船','卖针线的行商蹲在旧灯下，拿一截蓝布包住灯油壶。他说今夜换他守，叫铁柏放心回家吃饭。'],
  ['灯前听钟','雾遮住旧灯时，新钟先响了。行商掀开油布，直到湿漉漉的船头撞上软绳，才把茶倒进第二只碗。'],
  ['一河双灯','行商把新灯送到对岸。两团灯影夹着河心，晚归的船夫第一次敢把桨递给女儿，让她自己找回家的水路。']
 ];
 const [title, passage] = scenes[autumn];
 modalBox(title,'<p>'+passage+'</p>',[{label:'翻开渡口来信',on:'riverLetters',primary:true},{label:'离开桥头',on:'close'}]);
}
