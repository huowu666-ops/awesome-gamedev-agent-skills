function letterCalendar(day, choices) {
 const current = SEASONS.indexOf(seasonOf(day));
 const daysLeft = 7 - (day - 1) % 7;
 if (!choices[current]) {
  return daysLeft === 1 ? '今日是本季回信的最后一天。' : '本季还可回信 ' + daysLeft + ' 天（含今日）。';
 }
 for (let offset = 1; offset < SEASONS.length; offset++) {
  const next = (current + offset) % SEASONS.length;
  if (!choices[next]) {
   const date = day + daysLeft + 7 * (offset - 1);
   const letter = riverLetters[next];
   return '下一封 · 第' + date + '日（' + letter.season + '）｜' + letter.author + '《' + letter.title + '》';
  }
 }
 return '四季书信已回齐。可在信册中重读渡口的结局。';
}
