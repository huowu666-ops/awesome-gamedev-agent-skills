from pathlib import Path

root = Path(__file__).resolve().parents[1]
page = (root / 'baseline/V46.html').read_text()
def replace(before, after):
    global page
    assert page.count(before) == 1, before
    page = page.replace(before, after)

replace('function riverLetterBook(){', (root / 'source/V47_bridge.js').read_text() + '\nfunction riverLetterBook(){')
replace("'<p>'+letter.text+'</p><div", "'<p>'+autumnRequest(letter)+'</p><div")
replace('drawFerryModel(x,y,state.riverChoices[2])','drawFerryModel(x,y,bridgeMarker())')
replace('y===4&&!!state.riverChoices[2]', 'y===4&&!!bridgeMarker()')
replace('y===4&&state.riverChoices[2])return riverLetterBook()', 'y===4&&bridgeMarker())return visitBridgeMarker()')
replace('window.V46=window.V45','window.V47=window.V46=window.V45')
(root / 'index.html').write_text(page)
