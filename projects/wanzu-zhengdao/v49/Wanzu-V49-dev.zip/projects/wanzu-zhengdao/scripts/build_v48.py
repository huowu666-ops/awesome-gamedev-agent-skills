from pathlib import Path

root = Path(__file__).resolve().parents[1]
page = (root / 'baseline/V47.html').read_text()
anchor = "  return targets.filter(v=>v.dist<=1).sort((a,b)=>a.dist-b.dist)[0]||null;}"
assert page.count(anchor) == 1
page = page.replace(anchor, """  if (state.area === 'river' && bridgeMarker()) {
   const dx = 7 - state.x, dy = 4 - state.y;
   const dist = Math.abs(dx) + Math.abs(dy);
   if (dist <= 1) {
    const direction = dx > 0 ? 'right' : dx < 0 ? 'left' : dy > 0 ? 'down' : 'up';
    const marker = {x:7, y:4, dist};
    // A tie with the tea stall follows the player when facing the marker.
    if (dist === 0 || state.face === direction) targets.unshift(marker);
    else targets.push(marker);
   }
  }
""" + anchor)
assert page.count('window.V47=window.V46') == 1
(root / 'index.html').write_text(page.replace('window.V47=window.V46','window.V48=window.V47=window.V46'))
