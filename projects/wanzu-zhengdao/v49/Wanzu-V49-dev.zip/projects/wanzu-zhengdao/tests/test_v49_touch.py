import os
from pathlib import Path
from playwright.sync_api import sync_playwright

game = (Path(__file__).resolve().parents[1] / 'index.html').as_uri()
with sync_playwright() as pw:
    browser = pw.chromium.launch(channel=os.getenv('WANZU_BROWSER_CHANNEL'))
    for width, height in [(320,640), (375,667), (390,844)]:
        page = browser.new_page(offline=True, has_touch=True, viewport={'width':width,'height':height})
        page.goto(game, wait_until='commit')
        page.get_by_role('button', name='进入自由修行', exact=True).tap()
        page.evaluate('''() => {const s=V49.getState();s.day=28;s.riverChoices=[0,1,2,0];V49.debugState(s)}''')
        page.get_by_role('button', name='本季来信', exact=True).tap()
        panel = page.get_by_role('dialog')
        assert '最后一天' in panel.inner_text()
        replies = panel.locator('[data-do^="riverReply:"]')
        assert replies.count() == 2
        for button in replies.all():
            box = button.bounding_box()
            assert box and 0 <= box['y'] < box['y'] + box['height'] <= height
        replies.first.tap()
        assert '第29日（春）｜沈禾《一畦药苗》' in panel.inner_text()
        panel.get_by_role('button',name='收起信册').tap()
        page.get_by_role('button',name='本季回信',exact=True).tap()
        assert '第29日（春）' in panel.inner_text()
        page.close()
    browser.close()
