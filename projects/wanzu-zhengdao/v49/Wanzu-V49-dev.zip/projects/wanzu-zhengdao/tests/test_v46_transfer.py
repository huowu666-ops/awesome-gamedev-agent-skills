import os
from pathlib import Path
from playwright.sync_api import sync_playwright

game = (Path(__file__).resolve().parents[1] / 'index.html').as_uri()
with sync_playwright() as pw:
    browser = pw.chromium.launch(channel=os.getenv('WANZU_BROWSER_CHANNEL'),args=['--no-sandbox'])
    for stage, choice, action in [('lamp','做一盏桥头灯','举灯照亮石阶'),('bell','铸一口渡雾钟','敲钟接船')]:
        source = browser.new_context(offline=True)
        page = source.new_page()
        page.goto(game,wait_until='commit')
        page.wait_for_function('Boolean(window.V47)')
        for label in ['开始游戏','走到桥头','帮铁柏引船',choice]:
            page.get_by_role('button',name=label,exact=True).click()
        code = page.evaluate('V46.saveCode()')
        source.close()
        target = browser.new_context(offline=True,viewport={'width':320,'height':640},has_touch=True)
        page = target.new_page()
        page.goto(game,wait_until='commit')
        page.wait_for_function('Boolean(window.V47)')
        page.get_by_role('button',name='进入自由修行',exact=True).tap()
        page.locator('.v42-more summary').tap()
        page.locator('.v42-more [data-do=saves]').tap()
        page.locator('[data-do=import]').tap()
        page.locator('#v27-import').fill(code)
        page.locator('[data-do=importConfirm]').tap()
        assert page.evaluate('V46.getState().ferryStage') == stage
        assert page.evaluate('V46.restorePoints().length') > 0
        page.reload(wait_until='commit')
        page.wait_for_function('Boolean(window.V47)')
        page.get_by_role('button',name='回到渡口故事',exact=True).tap()
        page.get_by_role('button',name=action,exact=True).tap()
        assert page.locator('#night-title').inner_text() == '船靠岸了'
        target.close()
    browser.close()
print('PASS offline WZ27 transfer across clean profiles for bell and lamp')
