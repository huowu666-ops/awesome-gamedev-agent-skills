const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const path = require('node:path');
const html = fs.readFileSync(path.join(__dirname, '../index.html'), 'utf8');
const seasons = ['春','夏','秋','冬'];
const seasonOf = day => seasons[Math.floor((day - 1) / 7) % 4];
const env = { SEASONS: seasons, seasonOf };
const letters = html.slice(html.indexOf('const riverLetters ='), html.indexOf('// Tile coordinates deliberately'));
const calendar = html.slice(html.indexOf('function letterCalendar('), html.indexOf('function riverLetterBook('));
vm.runInNewContext(letters + calendar, env);
for (let day = 1; day <= 56; day++) {
 for (let mask = 0; mask < 16; mask++) {
  const choices = seasons.map((_, i) => (mask >> i) & 1);
  const hint = env.letterCalendar(day, choices);
  const pending = d => !choices[seasons.indexOf(seasonOf(d))];
  if (pending(day)) {
   let end = day;
   while (seasonOf(end + 1) === seasonOf(day)) end++;
   assert.ok(end === day ? hint.includes('最后一天') : hint.includes(' ' + (end-day+1) + ' 天'));
  } else if (mask === 15) {
   assert.ok(hint.includes('已回齐'));
  } else {
   let next = day + 1;
   while (!pending(next)) next++;
   assert.ok(hint.includes('第' + next + '日（' + seasonOf(next) + '）'));
  }
 }
}
console.log('PASS calendar: 56 days x 16 reply histories');
