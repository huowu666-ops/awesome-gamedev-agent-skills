import os
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
with sync_playwright() as pw:
    browser=pw.chromium.launch(channel=os.getenv('WANZU_BROWSER_CHANNEL'),args=['--no-sandbox'])
    for width,height in [(320,640),(375,667),(390,844)]:
        page=browser.new_page(viewport={'width':width,'height':height},has_touch=True,offline=True)
        page.goto((root/'index.html').as_uri(),wait_until='commit')
        page.wait_for_function('Boolean(window.V47)')
        page.get_by_role('button',name='进入自由修行',exact=True).tap()
        page.reload(wait_until='commit')
        page.wait_for_function('Boolean(window.V47)')
        page.get_by_role('button',name='继续自由修行',exact=True).tap()
        assert page.locator('.v42-primary button').count()==3
        page.locator('.v42-more summary').click()
        assert page.locator('[data-do="v40Hearts"]').is_visible()
        page.locator('.v42-more summary').click()
        assert not page.locator('[data-do="v40Hearts"]').is_visible()
        for i,day in enumerate([1,8,15,22]):
            page.evaluate('(day)=>{let s=V43.getState();s.day=day;V43.debugState(s)}',day)
            page.locator('.v42-primary [data-do="riverLetters"]').click()
            modal=page.locator('#v27-modalhost')
            current=modal.locator('article').first
            assert ['春','夏','秋','冬'][i] in current.locator('b').inner_text()
            assert current.locator('button').count()==2
            for button in current.locator('button').all():
                box=button.bounding_box()
                assert box and box['y']>=0 and box['y']+box['height']<=height,box
            archive=modal.locator('details')
            assert not archive.locator('article').first.is_visible()
            archive.locator('summary').click()
            assert archive.locator('article').count()==3
            if i:
                assert '给渡口种解暑茶' in archive.inner_text()
            archive.locator('summary').click()
            page.locator('[data-do^="riverReply:"]').nth(i%2).click()
            assert not page.locator('[data-do^="riverReply:"]').count()
            if i==3:
                assert page.locator('.v42-ending').is_visible()
                assert '雾里传来一声钟响' in page.locator('.v42-ending').inner_text()
            page.locator('#v27-modalhost [data-do="close"]').click()
        assert page.evaluate('document.querySelector("#v27-app").scrollWidth<=innerWidth+5')
        page.reload(wait_until='commit')
        page.wait_for_function('Boolean(window.V47)')
        assert page.evaluate('V43.getState().riverChoices')==[1,2,1,2]
        page.close()
    browser.close()
print('PASS: three mobile viewports, toolbar, seasonal replies, ending, reload')
