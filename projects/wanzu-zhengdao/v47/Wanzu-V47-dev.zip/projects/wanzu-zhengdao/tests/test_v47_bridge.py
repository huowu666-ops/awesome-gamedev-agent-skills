from pathlib import Path
from playwright.sync_api import sync_playwright

game = (Path(__file__).resolve().parents[1] / 'index.html').as_uri()
branches = {
    'bell': ('渡口试声', '两岸应钟', '循声见灯', '旧钟绳'),
    'lamp': ('灯下候船', '灯前听钟', '一河双灯', '擦净烟灰'),
}
with sync_playwright() as pw:
    browser = pw.chromium.launch()
    for width, height in [(320,640), (375,667), (390,844)]:
        for stage, (before, bell, lamp, prompt) in branches.items():
            for pick, after in [(1,bell), (2,lamp)]:
                page = browser.new_page(viewport={'width':width,'height':height},has_touch=True,offline=True)
                page.goto(game)
                page.get_by_role('button',name='进入自由修行',exact=True).tap()
                page.evaluate("""stage => {
                    const state=V47.getState();
                    Object.assign(state,{day:15,area:'river',ferryStage:stage+'-dawn',riverChoices:[1,2,0,0]});
                    V47.debugState(state);
                    V47.riverInteract(7,4);
                }""", stage)
                modal = page.locator('#v27-modalhost')
                assert before in modal.inner_text()
                modal.get_by_role('button',name='翻开渡口来信').tap()
                assert prompt in modal.inner_text()
                buttons=modal.locator('[data-do^="riverReply:"]')
                for btn in buttons.all():
                    box=btn.bounding_box()
                    assert box and box['y']>=0 and box['y']+box['height']<=height, box
                buttons.nth(pick-1).tap()
                modal.locator('[data-do=close]').tap()
                page.reload()
                page.get_by_role('button',name='继续自由修行').tap()
                page.evaluate('V47.riverInteract(7,4)')
                assert after in modal.inner_text()
                page.close()
    browser.close()
print('PASS four branch combinations at three touch sizes, offline replies and reload')
