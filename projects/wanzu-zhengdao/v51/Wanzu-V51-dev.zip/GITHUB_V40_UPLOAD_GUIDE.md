# GitHub V40 升级包布局

本 ZIP 已使用可直接放入 GitHub 仓库根目录的结构。`projects/wanzu-zhengdao/` 存放 V40 完整游戏工程，`.github/workflows/wanzu-v40-verify.yml` 是新增静态检查工作流。不会包含或修改原有 `skills/` 或 `router/` 目录。

当前聊天 GitHub 集成写入仍返回 403，**本 ZIP 并未自动推送**。

建议在有写入权限的工作环境将 ZIP 解压到仓库工作区，再审查 diff 并提交。在公开仓库执行前请注意 V40 源码/素材会公开。

单文件游戏入口：`projects/wanzu-zhengdao/index.html`。
