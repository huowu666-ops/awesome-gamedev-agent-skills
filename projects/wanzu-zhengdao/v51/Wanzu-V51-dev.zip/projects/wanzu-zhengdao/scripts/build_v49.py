from pathlib import Path

root = Path(__file__).resolve().parents[1]
page = (root / 'baseline/V48.html').read_text()
calendar = (root / 'source/V49_letter_calendar.js').read_text()
for before, after in [
    ('function riverLetterBook(){', calendar + '\nfunction riverLetterBook(){'),
    ('每七日换季。错过的信可在来年同季回复。', "'+letterCalendar(state.day,state.riverChoices)+'"),
    ("if(!FT.on&&document.title!=='万族争道 · V29 四时山居')v19RefreshText();",
     """if (FT.on) return;
    const title = document.body.classList.contains('v27-open')
      ? '万族争道 · V49 渡口回信日历' : '万族争道 · V29 四时山居';
    if (document.title !== title) document.title = title;"""),
    ('window.V48=window.V47', 'window.V49=window.V48=window.V47'),
]:
    assert page.count(before) == 1, before
    page = page.replace(before, after)
(root / 'index.html').write_text(page)
