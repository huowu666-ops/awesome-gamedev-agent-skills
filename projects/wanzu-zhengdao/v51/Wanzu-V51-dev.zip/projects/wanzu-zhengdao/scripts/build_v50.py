from pathlib import Path

root = Path(__file__).resolve().parents[1]
page = (root / 'baseline/V49.html').read_text()
before = """host.insertBefore(err,host.querySelector('.modalactions')||null)}err.textContent=t"""
after = """err.setAttribute('role','alert');
 const replies=host.querySelector('[data-do^="riverReply:"]')?.closest('.v40-buttons');
 host.insertBefore(err,host.querySelector('.modalactions')||null);
 if(replies) replies.before(err);
 }err.textContent=storageFault && host.querySelector('[data-do^="riverReply:"]')
   ? '回信未保存。请检查浏览器存储空间或权限，再点一次回复。' : t"""
assert page.count(before) == 1
page = page.replace(before, after)
assert page.count('window.V49=window.V48') == 1
(root / 'index.html').write_text(page.replace('window.V49=window.V48', 'window.V50=window.V49=window.V48'))
