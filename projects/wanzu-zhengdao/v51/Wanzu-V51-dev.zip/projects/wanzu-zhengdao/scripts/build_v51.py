from pathlib import Path

root = Path(__file__).resolve().parents[1]
page = (root / 'baseline/V50.html').read_text()
before = """ if (!marker) return riverLetterBook();
 const autumn = state.riverChoices[2];"""
after = """ const autumn = state.riverChoices[2];
 if (!marker) {
  if (!autumn) return riverLetterBook();
  const bell = autumn === 1;
  const title = bell ? '槐下第一声' : '桥灯照浅滩';
  const passage = bell
   ? '铁柏把钟槌递给撑渡的小姑娘。她敲了三下，芦苇那头也回了三下桨声。那条困在雾里的船，循着她的手靠了岸。'
   : '桥头灯刚亮，挑药的老汉便停了脚。灯影底下，原来那级石阶已被秋水没过。铁柏扶他从高处上船，又在扶手上刻下一道水痕。';
  modalBox(title,'<p>'+passage+'</p>',[{label:'翻开渡口来信',on:'riverLetters',primary:true},{label:'离开桥头',on:'close'}]);
  return;
 }"""
assert page.count(before) == 1
assert page.count('window.V50=window.V49') == 1
(root / 'index.html').write_text(page.replace(before, after).replace('window.V50=window.V49','window.V51=window.V50=window.V49'))
