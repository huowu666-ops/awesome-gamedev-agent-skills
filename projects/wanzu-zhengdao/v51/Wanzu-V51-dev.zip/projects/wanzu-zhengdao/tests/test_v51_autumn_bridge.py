import os
from pathlib import Path
from playwright.sync_api import sync_playwright

root = Path(__file__).resolve().parents[1]
with sync_playwright() as pw:
    browser = pw.chromium.launch(channel=os.getenv('WANZU_BROWSER_CHANNEL'))
    for filename in ['baseline/V50.html', 'index.html']:
        for pick, title in [(1,'槐下第一声'), (2,'桥灯照浅滩')]:
            page = browser.new_page(offline=True, has_touch=True, viewport={'width':320,'height':568})
            page.goto((root / filename).as_uri(), wait_until='commit')
            page.get_by_role('button', name='进入自由修行', exact=True).tap()
            page.evaluate("""() => {
                const s = V50.getState();
                Object.assign(s,{day:15,area:'river',tool:'hand',x:6,y:4,face:'right'});
                V50.debugState(s);
            }""")
            page.get_by_role('button', name='本季来信', exact=True).tap()
            panel = page.get_by_role('dialog')
            panel.locator('[data-do^="riverReply:"]').nth(pick-1).tap()
            panel.get_by_role('button', name='收起信册').tap()
            page.reload(wait_until='commit')
            page.get_by_role('button',name='继续自由修行').tap()
            page.get_by_role('button',name='交互',exact=True).tap()
            if filename == 'index.html':
                assert title in panel.inner_text()
                panel.get_by_role('button',name='翻开渡口来信').tap()
            assert '渡口来信' in panel.inner_text()
            assert page.evaluate('V50.getState().riverChoices[2]') == pick
            page.close()
