import os
from pathlib import Path
from playwright.sync_api import sync_playwright

root = Path(__file__).resolve().parents[1]
with sync_playwright() as pw:
    browser = pw.chromium.launch(channel=os.getenv('WANZU_BROWSER_CHANNEL'))
    for width,height in [(320,640),(375,667),(390,844)]:
        for path, fixed in [('baseline/V49.html',False),('index.html',True)]:
            page = browser.new_page(offline=True, has_touch=True, viewport={'width':width,'height':height})
            page.goto((root / path).as_uri(), wait_until='commit')
            page.get_by_role('button',name='进入自由修行',exact=True).tap()
            page.get_by_role('button',name='本季来信',exact=True).tap()
            panel = page.get_by_role('dialog')
            panel.locator('summary').tap()
            choice = panel.locator('[data-do="riverReply:0:1"]')
            page.evaluate("""() => {
                const write = Storage.prototype.setItem;
                Storage.prototype.setItem = function(key,value) {
                    if(key==='wanzu_v27_pixel_sanctuary') throw new DOMException('full','QuotaExceededError');
                    return write.call(this,key,value);
                };
                window.restoreWrites = () => {Storage.prototype.setItem = write};
            }""")
            for _ in range(2):
                choice.tap()
                assert page.evaluate('V49.getState().riverChoices[0]') == 0
                error = panel.locator('.v29-modalerror')
                assert error.count() == 1
                beside = error.evaluate("e => e.nextElementSibling?.classList.contains('v40-buttons')")
                assert bool(beside) == fixed
                if fixed:
                    assert '回信未保存' in panel.get_by_role('alert').inner_text()
                    box=error.bounding_box()
                    assert box and 0<=box['y'] and box['y']+box['height']<=height
            page.evaluate('restoreWrites()')
            choice.tap()
            assert page.evaluate('V49.getState().riverChoices[0]') == 1
            assert panel.locator('.v29-modalerror').count() == 0
            assert '下一封' in panel.inner_text()
            page.reload(wait_until='commit')
            page.get_by_role('button',name='继续自由修行').tap()
            assert page.evaluate('V49.getState().riverChoices[0]') == 1
            page.close()
    browser.close()
print('PASS offline failure, visible retry feedback, recovery and reload at three touch sizes')
