import os
from pathlib import Path
from playwright.sync_api import sync_playwright

root=Path(__file__).resolve().parents[1]
with sync_playwright() as pw:
    browser=pw.chromium.launch(channel=os.getenv('WANZU_BROWSER_CHANNEL'))
    for file, fixed in [('baseline/V55.html',False),('index.html',True)]:
        for stage,quote,other in [('start','炉里剩的铁','lamp-dawn'),('lamp-dawn','擦净烟灰','bell-dawn'),('bell-dawn','旧钟绳','lamp-dawn')]:
            page=browser.new_page(offline=True,has_touch=True,viewport={'width':320,'height':568})
            page.goto((root/file).as_uri(),wait_until='commit')
            def tap(label):
                page.get_by_role('button',name=label,exact=True).tap()
            tap('进入自由修行')
            page.evaluate("(stage)=>{const s=V55.getState();Object.assign(s,{day:15,ferryStage:stage});V55.debugState(s)}",stage)
            panel=page.get_by_role('dialog')
            tap('本季来信')
            assert quote in panel.inner_text()
            tap('打一盏桥头灯')
            assert (quote in panel.inner_text())==fixed
            if fixed:
                tap('收起信册')
                page.evaluate("(stage)=>{const s=V55.getState();Object.assign(s,{day:22,ferryStage:stage});V55.debugState(s);V55.save()}",other)
                page.reload(wait_until='commit')
                tap('继续自由修行')
                tap('本季来信')
                panel.locator('summary').tap()
                autumn=panel.locator('article').filter(has_text='炉上余铁')
                assert quote in autumn.inner_text() and '你的回信' in autumn.inner_text()
                assert '船夫伸手' not in autumn.inner_text() and '灯罩打成了鱼鳞纹' in autumn.inner_text()
                tap('收起信册')
                page.evaluate("()=>{const s=V55.getState();delete s.autumnLetterMarker;V55.debugState(s)}")
                tap('本季来信')
                panel.locator('summary').tap()
                assert '来信大意' in autumn.inner_text()
            page.close()
    browser.close()
