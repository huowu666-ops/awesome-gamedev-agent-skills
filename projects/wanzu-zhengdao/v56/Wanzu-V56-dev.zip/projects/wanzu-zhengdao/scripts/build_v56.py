from pathlib import Path

root = Path(__file__).resolve().parents[1]
page = (root / 'baseline/V55.html').read_text()

def edit(before, after):
    global page
    assert page.count(before) == 1, before
    page = page.replace(before, after)

edit('winterReplyDay:0,meals:', 'winterReplyDay:0,autumnLetterMarker:null,meals:')
edit(' a.winterReplyDay=0;', """ a.autumnLetterMarker=a.riverChoices[2] && [0,1,2].includes(x.autumnLetterMarker) ? x.autumnLetterMarker : null;
 a.winterReplyDay=0;""")
edit("function autumnRequest(letter) {\n if (letter.season !== '秋') return letter.text;\n const marker = firstNightMarker();", """function autumnRequest(letter, marker=firstNightMarker()) {
 if (letter.season !== '秋') return letter.text;
 if (marker === null) return '铁柏托你决定，炉里的余铁用来铸钟，还是做一盏桥头灯。';""")
edit("  if(pick) body='<p>'+letter.choices[pick-1]+'。'+letter.replies[pick-1]+'</p>';",
"""  if(pick) {
   const label=i===2 && state.autumnLetterMarker===null ? '来信大意' : '来信';
   body='<p><b>'+label+'</b>　'+autumnRequest(letter,state.autumnLetterMarker)+'</p>'+
    '<p><b>你的回信</b>　'+letter.choices[pick-1]+'</p><p><b>后来</b>　'+letter.replies[pick-1]+'</p>';
  }""")
edit('  s.riverChoices[i]=pick;', '  s.riverChoices[i]=pick;\n  if(i===2)s.autumnLetterMarker=firstNightMarker();')
edit('window.V55=window.V54','window.V56=window.V55=window.V54')
(root/'index.html').write_text(page)
