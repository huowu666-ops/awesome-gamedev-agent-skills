# GitHub 同仓库同步状态（2026-11-13）

项目现有公开仓库：[huowu666-ops/awesome-gamedev-agent-skills](https://github.com/huowu666-ops/awesome-gamedev-agent-skills)。

- **V34**：已于 2026-11-13 通过自动展开工作流提交至 `projects/wanzu-zhengdao/`，提交号 `24d43cde758e76a9110b1ca9983387eed352eb75`，并保留 Agent Skills 根目录。
- **V35、V36、V37、V38**：此前完成了本地 HTML、开发包和自动测试，不代表云端已同步。请以 GitHub 最近提交与实际文件为准。
- 当前 ChatGPT GitHub 集成的写入请求曾多次得到 403 `Resource not accessible by integration`，因此不应声明 V38 已自动上传。
- 上传时只更新 `projects/wanzu-zhengdao/` 对应文件；仓库根目录 `skills/`、`router/` 和其它 Agent Skills 文件不能覆盖。若安装工作流，需在仓库根目录 `.github/workflows/` 新增文件。
