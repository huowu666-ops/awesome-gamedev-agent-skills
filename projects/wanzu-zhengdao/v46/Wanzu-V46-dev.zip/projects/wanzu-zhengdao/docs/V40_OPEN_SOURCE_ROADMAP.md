# 《万族争道》V40 — 第二轮开源项目评估与落地

> 检索与核对：2026-11-13。只集成许可证允许且适用于自研 HTML + Canvas 2D 的技术。不为引入依赖而换引擎。链接用于追踪授权和上游更新，并非所有仓库的代码已复制进游戏。

| 项目及官方来源 | 许可（源站核对） | 收益与实际取舍 | 当前状态 |
|---|---|---|---|
| [mourner/tinyqueue](https://github.com/mourner/tinyqueue) | ISC | A* 的优先队列；保留作者许可证 | **V39 已集成源码** |
| [jakesgordon/javascript-state-machine](https://github.com/jakesgordon/javascript-state-machine) | MIT | FSM 状态、显式转移；V40 为原创轻量状态表，不拷贝其源码 | **V40 已借鉴架构** |
| [goldfire/howler.js](https://github.com/goldfire/howler.js) | MIT | 统一 Web Audio、移动端手势解锁；V40 使用原创 Web Audio 合成提示声，未拷贝 Howler 源码 | **V40 借鉴原则**；音频复杂后可评估正式引入 |
| [yoannmoinet/nipplejs](https://github.com/yoannmoinet/nipplejs) | MIT | 手机模拟摇杆；先在真 iPhone 测当前方向键、长按与滑动冲突 | 候选，不引入 |
| [ondras/rot.js](https://github.com/ondras/rot.js) | BSD-3-Clause | 地牢、阴影视野与随机地图；需与现有 12×8 模板和任务位置保持一致 | 候选，暂不引入 |
| [y-lohse/inkjs](https://github.com/y-lohse/inkjs) | MIT | 长篇分支剧情、状态变量、存档迁移；现有 NPC 委托只需轻量规则 | 未来大型剧情线使用 |
| [jakearchibald/idb-keyval](https://github.com/jakearchibald/idb-keyval) | Apache-2.0 | IndexedDB 小键值备份；V39 使用独立轻量实现，没有复制库代码 | **V39 已借鉴思路** |
| [prettymuchbryce/easystarjs](https://github.com/prettymuchbryce/easystarjs) | 请按目标标签核对 | 分帧网格寻路；V39 A* 在 200 个随机网格上已核对，暂无迁移必要 | 暂缓 |
| [pixijs/pixijs 性能规范](https://pixijs.com/8.x/guides/concepts/performance-tips) | 文档供参考，具体代码另行核对 | 先测 FPS、重绘次数、耗电，再决定局部纹理缓存和剔除；不可直接假定 Canvas 有 Pixi API | 方法论，尚未改用 Pixi |
| [Kenney Roguelike/RPG](https://kenney.nl/assets/roguelike-rpg-pack) | CC0 | 1700 个 16×16 像素素材；透视/配色与既有 32/64px 水墨风格不一致 | 仅筛选，**未复制素材** |
| [Kenney UI Pack](https://kenney.nl/assets/ui-pack) | CC0 | 按钮、面板素材；必须统一黛青/冷灰绿/金色审美 | 候选，未复制 |
| [Pixel-Boy Ninja Adventure](https://pixel-boy.itch.io/ninja-adventure-asset-pack) | CC0（作者页面） | 完整像素动画/音效；原包约 89 MB，且忍者风格与仙侠不一致 | 候选，未复制 |
| [feross/simple-peer](https://github.com/feross/simple-peer) | MIT | WebRTC；当前目标是单机离线，增加联机将带来同步/滥用复杂度 | 暂不引入 |

## V40 实际代码变更

1. **可解释的 NPC 行为状态**：`work` / `social` / `shelter` / `rest` 4 种状态，遵循天气、时辰、关系阈值判定；不修改原 V31/V36 NPC 实际碰撞与寻路轨迹，以免破坏跨区寻访。
2. **每日当面问候**：玩家必须站在 NPC 附近两格以内，每位 NPC 每日仅一次；缘分 +2，闲谈状态 +3；街坊声望 +1；先将更改通过 `change()` 写盘，失败无奖励；笔记记录结果。
3. **Web Audio 轻提示音**：原创正弦波，初次使用默认静音，用户点击「开启」后才能启动浏览器音频；无 CDN、外部音效或自动播放，独立开关不污染 `WZ27` 存档结构。
4. **兼容 V27–V39**：`window.V40` 与全部旧 API 指向同一游戏，`npcCareDay` 通过白名单校验并为旧数据补默认值。
5. **小屏可用**：按钮最小 46px，五族心境卡片和音效面板在 320px 宽度测试无横向溢出。

## 下一轮最有性价比的顺序

- **P0 真机**：iPhone Safari 网页入口与 `file://` 存档、IndexedDB；导出存档与还原后重新进入，测试不丢失。最低成本，最高风险缓解。
- **P1 内容**：利用 inkjs/Yarn Spinner 的“剧情节点、条件分支、状态验证”思想设计新的原创跨季人物事件；不要先全盘迁移已有任务。
- **P1 表现**：一套统一中国风 CC0 衍生资产配色/轮廓规范，先改 10 枚 UI 图标和 3 个地标，而非替换 137 张像素素材。
- **P2 地图**：局部雾/光照与地牢变化，需跑可达性测试并保持旧存档落点。
- **P2 手机**：NippleJS 虚拟摇杆原型，先用户测试、可切换返回十字方向键，避免与滚动冲突。
- **P3 联机**：单机主线通关、存档稳定之后再考虑。

## 许可证规则

- V40 没有复制 javascript-state-machine、howler.js、NippleJS、ROT.js、Kenney 或 Pixel-Boy 的代码/资产；其**架构或公开规范作为设计参考**。
- 复制开源代码要附原许可证全文、版权声明及必要的 NOTICE；素材须逐项核实具体文件许可证。CC0 允许商业使用，仍建议记录来源以便审计。
- `TinyQueue` ISC 许可证及声明在 `third_party/tinyqueue/LICENSE`、以及游戏 JS 的已有注释中。
