# V39 开源项目选型和版权清单

检索日期：2026-11-13。**所有外部依赖都必须遵守各自许可证**，不能将 GitHub 上找到的素材笼统认定为可商用。

| 项目 | 许可证 | 适用价值 | 本次处理 |
|---|---|---|---|
| [mourner/tinyqueue](https://github.com/mourner/tinyqueue) | ISC | 二叉堆优先队列，支撑 A* 的开放列表 | **已集成**，附完整 ISC 声明；无运行时网络依赖 |
| [prettymuchbryce/easystarjs](https://github.com/prettymuchbryce/easystarjs) | MIT | 异步 A*，支持迭代预算、方向与地图成本 | **借鉴设计目标**，未复制或引入源码；地图只有 12×8 暂不需要完整库 |
| [jakearchibald/idb-keyval](https://github.com/jakearchibald/idb-keyval) | Apache-2.0 | 浏览器 IndexedDB 的轻量键值备份 | **参考存储架构**，针对离线单文件独立原创实现；未复制库代码 |
| [goldfire/howler.js](https://github.com/goldfire/howler.js) | MIT | Web Audio / HTML5 音频兼容、iOS 音频解锁 | 以后按需引入，当前已有原生音效，不增加体积 |
| [jakesgordon/javascript-state-machine](https://github.com/jakesgordon/javascript-state-machine) | MIT | NPC 对话和任务状态机 | 后续角色深度开发评估，不做无必要的大规模重构 |
| [Kenney Roguelike/RPG Pack](https://kenney.nl/assets/roguelike-rpg-pack) | CC0 | 16×16 物品/地图/界面资产 | 候选素材；**本次未导入**，需先与现有原创 32/64 像素风格统一 |

## 已集成内容与约束
- A* 使用 TinyQueue 的二叉堆，4 向移动、NPC 动态占位、交互格需站邻位、BFS 旧接口 `pathTo()` 都保留。采用自适应启发函数到多个交互邻格，距离为曼哈顿距离。
- IndexedDB 镜像在**localStorage 成功**之后延后写入，是独立后备副本；完全不参与资金/道具事务提交。若无法打开 IDB，自动存档仍照常运作。镜像有 FNV-1a 误损校验（**不属于加密签名**），恢复前先生成 V35 快照；明确提示 Safari 网站数据可能被整体清理。
- `index.html` 单文件可离线使用，内嵌 TinyQueue 的 ISC 著作权与许可声明，并在 `third_party/tinyqueue/LICENSE` 单独保留声明。
- 本版没有联网跟踪、外部字体、第三方音频或未经确认的素材包。仓库原有 Agent Skills 许可与游戏创作内容许可分开管理。
