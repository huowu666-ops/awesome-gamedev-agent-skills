# 《万族争道》开源项目引入路线 · 可执行优先级

## P0 已交付（V39）

1. [TinyQueue](https://github.com/mourner/tinyqueue) · ISC：已引入 A* 的队列核心（有许可文件），让路线规划接口不依赖 BFS 全表扫描。须保持与 V36 动态寻路和站邻格交互一致。
2. [idb-keyval](https://github.com/jakearchibald/idb-keyval) · Apache-2.0：**参考设计，不复制代码**；实现 IndexedDB 独立镜像、校验、确认恢复和存档快照。

## P1 下一批适合实际开发的方向

3. [javascript-state-machine](https://github.com/jakesgordon/javascript-state-machine) · MIT：NPC 情绪与支线从散落条件判断转为限定有限状态，分阶段试做青妩一人；通过存档白名单测试才推广到全五族。
4. [EasyStar.js](https://github.com/prettymuchbryce/easystarjs) · MIT：将来地图扩至数百/数千格时评估逐帧 A* 的计算预算，避免手机触摸卡顿；V39 12×8 地图暂不引入第二套 A*。
5. [howler.js](https://github.com/goldfire/howler.js) · MIT：只有确定需要预录 BGM/立体声时才考虑集成，音频必须由用户手势解锁；当前 V39 保持轻量音效。
6. [Kenney Roguelike/RPG Pack](https://kenney.nl/assets/roguelike-rpg-pack) · CC0：候选扩图道具与UI参考；需先审美统一并重新检验授权，不替换原有角色与地图美术。

## P2 不宜当前一次性引入

- 整套 Godot/Unity/Phaser：现有原生 Canvas 能离线在 iPhone 运行，完全迁移会破坏 save format 和旧引擎。只能在决定重构时做隔离原型。
- 随机下载“免费”游戏素材：**免费不代表可二次分发**，禁用许可不明或含版权角色的素材。
- 网络角色 AI / 外部 API / 实时服务器：会失去离线可玩性，并带来成本和用户数据安全风险。

## 验收标准

每次只引入最少的 1–2 项技术，保留许可文本；必须通过 `V27` 旧存档迁移、材料奖励写入失败回滚、NPC 避障、触控 320/375/390 屏幕测试，且整个游戏在离线状态可玩。
