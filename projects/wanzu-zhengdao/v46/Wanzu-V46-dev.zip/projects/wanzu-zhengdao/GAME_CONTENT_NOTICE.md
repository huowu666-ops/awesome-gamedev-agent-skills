# 《万族争道》内容与授权说明

本目录是独立游戏项目，与仓库根目录收录的 `awesome-gamedev-agent-skills` 技能库在目的与原创内容上相互区分。

- `../../LICENSE` 适用于上游技能库，其许可证为 Apache-2.0。
- 《万族争道》的原创剧情、角色设定、美术与游戏内容不因被放到公开 GitHub 仓库而自动授予第三方重用许可。
- 如后续希望开源游戏代码或开放素材授权，应由权利人另行确定具体许可证与第三方素材权属。
- 本次没有纳入原技能库的代码到游戏运行时。

项目维护者在公开任何外来字体、音频、图片、源代码之前，应先确认其许可与再分发条件。


## V39 第三方源码

`TinyQueue` 二叉堆来自 Vladimir Agafonkin 的 [`mourner/tinyqueue`](https://github.com/mourner/tinyqueue)，适用 ISC 许可证。本项目在单文件 HTML 内保留完整许可与版权声明，并在 `third_party/tinyqueue/LICENSE` 独立保存。

IndexedDB 镜像是针对本游戏自行实现的适配器，参考 [`jakearchibald/idb-keyval`](https://github.com/jakearchibald/idb-keyval) 的数据存储方式；**未引入或复制该库的代码**。其它候选库与 CC0 素材均未复制进 V39。详见 `docs/V39_OPEN_SOURCE_REVIEW.md`。
