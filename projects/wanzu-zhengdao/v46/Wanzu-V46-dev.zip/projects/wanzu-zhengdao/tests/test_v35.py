from pathlib import Path
import json,sys
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/'index.html').read_text(encoding='utf-8')
BOOT='''() => {
 const m=new Map();window.__mockStore=m;window.__denyWrites=false;window.__denyAuto=false;
 Object.defineProperty(window,'localStorage',{configurable:true,value:{
 getItem:k=>m.get(k)||null,
 setItem:(k,v)=>{if(window.__denyWrites||(window.__denyAuto&&k==='wanzu_v27_pixel_sanctuary'))throw Error('SIMULATED_QUOTA');m.set(k,String(v))},
 removeItem:k=>m.delete(k),clear:()=>m.clear()}})
}'''
checks=[]
def ck(size,title,ok,detail=''):
 checks.append({'viewport':size,'check':title,'passed':bool(ok),'detail':'' if ok else str(detail)[:300]})
 if not ok:print('FAIL',size,title,detail,flush=True)
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for w,h in [(390,844),(375,667),(320,640)]:
  context=browser.new_context(viewport={'width':w,'height':h},device_scale_factor=1,has_touch=True,is_mobile=True,accept_downloads=True)
  page=context.new_page();errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
  page.evaluate(BOOT)
  page.set_content(HTML,wait_until='domcontentloaded',timeout=60000)
  page.wait_for_function('typeof V35!=="undefined"',timeout=30000)
  page.evaluate('V35.open()')
  page.wait_for_timeout(250)
  size=f'{w}x{h}';ev=page.evaluate
  ck(size,'V35 and legacy aliases',ev('V35===V34&&V35===V27'))
  ck(size,'V35 launch + WZ27 schema',ev('V35.getState().mode')=='farm' and ev('V35.getState().v')==27)
  ck(size,'3 save controls',page.locator('#v35-save-health').count()==1)
  ck(size,'tracker intact',page.locator('.v34-tracker').count()==1)
  ck(size,'horizontal fit',ev('document.querySelector("#v27-app").scrollWidth<=innerWidth+5'))
  ck(size,'runtime audit',ev('V35.audit().passed===V35.audit().total'),ev('V35.audit()'))
  ck(size,'initial snapshots empty',ev('V35.restorePoints().length')==0)
  ev('V35.createRestorePoint()')
  ck(size,'snapshot created',ev('V35.restorePoints().length')==1)
  ev('''() => {let s=V35.getState();s.gold=321;V35.debugState(s);}''')
  ev('V35.createRestorePoint()')
  ck(size,'snapshot stores game state',ev('V35.restorePoints()[0].gold')==321)
  ck(size,'snapshot does not modify legacy game schema',ev('V35.getState().v')==27 and bool(ev("window.__mockStore.get('wanzu_v27_pixel_sanctuary')")))
  # multiple snapshots rotate and never exceed 3
  ev('V35.createRestorePoint()');ev('V35.createRestorePoint()')
  ck(size,'snapshot retention max 3',ev('V35.restorePoints().length')==3)
  # restore point index 2 is initial (180g) as current list is [321,321,321] after rotation; simulate different saves
  ev('''() => {const s=V35.getState();s.gold=567;V35.debugState(s)}''')
  ev('V35.restorePointConfirm(0)')
  ck(size,'restored snapshot',ev('V35.getState().gold')==321)
  ck(size,'pre-restore save protected',ev('V35.restorePoints()[0].gold')==567)
  # quota failure prevents snapshot change and in-memory state swap
  old_state=ev('V35.getState()')
  blocked=ev('''() => {window.__denyWrites=true;try{V35.createRestorePoint();return false}catch{return true}finally{window.__denyWrites=false}}''')
  ck(size,'quota failure raised',blocked)
  ck(size,'quota preserved current game state',ev('V35.getState().gold')==old_state['gold'])
  ck(size,'failed snapshot leaves list intact',ev('V35.restorePoints()[0].gold')==567)
  # snapshot is written but auto store denied: restore cannot change in-memory game state
  blocked_restore=ev('''()=>{window.__denyAuto=true;V35.restorePointConfirm(0);window.__denyAuto=false;return V35.getState().gold===321}''')
  ck(size,'save failure blocks restore',blocked_restore)
  ck(size,'save failure visible',page.locator('#v35-save-health.error').count()==1)
  # normal state returns to green on next persist
  ev('V35.save()')
  page.locator('[data-do="saves"]').first.click()
  ck(size,'save modal has snapshot options',page.locator('[data-do="v35Snapshot"]').count()==1)
  ck(size,'save modal lists 3 points',page.locator('.v35-snapshot').count()==3)
  page.locator('[data-do="import"]').click()
  ck(size,'file import picker',page.locator('#v35-import-file').count()==1)
  code=ev('V35.saveCode()')
  ck(size,'old code prefix',code.startswith('WZ27:'))
  page.locator('#v35-import-file').set_input_files({'name':'backup.txt','mimeType':'text/plain','buffer':code.encode('utf8')})
  page.wait_for_function('document.querySelector("#v27-import").value.startsWith("WZ27:")')
  ck(size,'TXT load into import modal',page.locator('#v27-import').input_value()==code)
  page.locator('[data-do="importConfirm"]').click()
  ck(size,'TXT import validated and restored',ev('V35.getState().gold')==321)
  # download TXT round-trip
  page.locator('[data-do="saves"]').first.click()
  with page.expect_download(timeout=15000) as info:
   page.locator('[data-do="v35Download"]').click()
  download=info.value
  ck(size,'download .txt',download.suggested_filename.endswith('.txt'))
  # guide from house, which was unavailable in V34
  ev('''()=>{let s=V35.getState();s.mode='farm';s.area='house';s.x=5;s.y=5;V35.debugState(s)}''')
  ev('''()=>{document.querySelector('#v27-modalhost [data-do=\"close\"]')?.click()}''')
  ck(size,'guide available indoors',ev('V36.guideStep().label')=='山居出口')
  ck(size,'no JS errors',not errs,errs)
  if w==390:
   page.locator('[data-do="saves"]').first.click()
   page.screenshot(path=str(ROOT/'previews/wz_v35_save_center.png'),animations='disabled')
  context.close()
 browser.close()
print('V35 RESULTS',sum(x['passed'] for x in checks),'/',len(checks))
(ROOT/'tests/v35_checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf8')
if not all(x['passed'] for x in checks):sys.exit(1)
