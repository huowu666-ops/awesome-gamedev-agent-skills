const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict');
const html=fs.readFileSync(__dirname+'/../index.html','utf8');
const js=html.match(/<script id="v27-pixel-sim-js">([\s\S]*?)<\/script>/)[1]
 .replace('window.V41=','window.reply=replyRiverLetter;window.V41=');
const data=new Map();let fail=false;
function boot(){
 const env={window:{},Image:class{},document:{readyState:'loading',addEventListener(){}},console,
 localStorage:{getItem:k=>data.get(k),setItem:(k,v)=>{if(fail)throw Error('quota');data.set(k,v)}},
 requestAnimationFrame(){},setTimeout(){},clearTimeout(){},structuredClone,Date};
 vm.runInNewContext(js,env);return env.window;
}
let game=boot();
for(let i=0;i<4;i++){
 const s=game.V41.getState();s.day=i*7+1;game.V41.debugState(s);
 assert.equal(game.reply((i+1)%4,1),false);
 fail=true;assert.equal(game.reply(i,1),false);fail=false;
 assert.equal(game.V41.getState().riverChoices[i],0);
 assert.equal(game.reply(i,1+i%2),true);
 assert.equal(game.reply(i,1),false);
 game=boot();assert.equal(game.V41.getState().riverChoices[i],1+i%2);
}
console.log('PASS: four seasons, gating, persistence, rollback and duplicate choices.');
