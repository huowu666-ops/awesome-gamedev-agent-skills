from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
with sync_playwright() as pw:
    browser=pw.chromium.launch(args=['--no-sandbox'])
    for width,height in [(320,640),(375,667),(390,844)]:
        page=browser.new_page(viewport={'width':width,'height':height},has_touch=True)
        page.goto((root/'index.html').as_uri())
        page.evaluate('V42.open()')
        assert page.locator('.v42-primary button').count()==3
        page.locator('.v42-more summary').click()
        assert page.locator('[data-do="v40Hearts"]').is_visible()
        page.locator('.v42-more summary').click()
        assert not page.locator('[data-do="v40Hearts"]').is_visible()
        for i,day in enumerate([1,8,15,22]):
            page.evaluate('(day)=>{let s=V42.getState();s.day=day;V42.debugState(s)}',day)
            page.locator('.v42-primary [data-do="riverLetters"]').click()
            page.locator('[data-do^="riverReply:"]').nth(i%2).click()
            assert not page.locator('[data-do^="riverReply:"]').count()
            if i==3:
                assert page.locator('.v42-ending').is_visible()
                assert '雾里传来一声钟响' in page.locator('.v42-ending').inner_text()
            page.locator('#v27-modalhost [data-do="close"]').click()
        assert page.evaluate('document.querySelector("#v27-app").scrollWidth<=innerWidth+5')
        page.reload()
        assert page.evaluate('V42.getState().riverChoices')==[1,2,1,2]
        page.close()
    browser.close()
print('PASS: three mobile viewports, toolbar, seasonal replies, ending, reload')
