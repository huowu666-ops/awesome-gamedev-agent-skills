from pathlib import Path
import sys,json
from playwright.sync_api import sync_playwright,TimeoutError as BrowserTimeout
ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/'index.html').read_text(encoding='utf8')
BOOT='''() => {const m=new Map();window.__mockStore=m;window.__denyWrites=false;
Object.defineProperty(window,'localStorage',{configurable:true,value:{
 getItem:k=>m.get(k)||null,
 setItem:(k,v)=>{if(window.__denyWrites)throw Error('SIMULATED_QUOTA');m.set(k,String(v))},
 removeItem:k=>m.delete(k),clear:()=>m.clear()}})}'''
checks=[]
def ck(sz,msg,ok,detail=''):
 checks.append({'size':sz,'name':msg,'pass':bool(ok),'detail':str(detail)[:200] if not ok else ''})
 if not ok: print('FAIL',sz,msg,detail,flush=True)
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for w,h in [(390,844)]:
  context=browser.new_context(viewport={'width':w,'height':h},has_touch=True,is_mobile=True,accept_downloads=True)
  page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.evaluate(BOOT);page.set_content(HTML,wait_until='domcontentloaded',timeout=60000)
  page.wait_for_function('typeof V36!=="undefined"')
  page.evaluate('V36.open()')
  sz=f'{w}x{h}';ev=page.evaluate
  ck(sz,'aliases preserved',ev('V36===V35 && V36===V34 && V36===V27'))
  ck(sz,'legacy code',ev('V36.saveCode().startsWith("WZ27:")'))
  ck(sz,'save center retained',page.locator('#v35-save-health').count()==1)
  ck(sz,'route status present',page.locator('#v36-guide-status').count()==1)
  ck(sz,'mobile fit',ev('document.querySelector("#v27-app").scrollWidth<=innerWidth+5'))
  ck(sz,'runtime audit',ev('V36.audit().passed===V36.audit().total'),ev('V36.audit()'))
  # Auto route from house through farm, village, river, ultimately shrine
  ev('''()=>{let s=V36.getState();s.area='house';s.x=5;s.y=5;s.minute=660;s.trackedQuest='river';V36.debugState(s)}''')
  ck(sz,'at house',ev('V36.getState().area')=='house')
  ck(sz,'start cross-map guide',ev('V36.guideTarget()') is True)
  ck(sz,'route active',ev('V36.guideStatus().active'))
  try:page.wait_for_function('V36.getState().area==="river" && !V36.guideStatus().active',timeout=20000)
  except BrowserTimeout: print('DEBUG house>river:',sz,ev('({state:V36.getState(),guide:V36.guideStatus(),modal:document.querySelector(".modal h2")?.textContent})'))
  ck(sz,'house->farm->village->river',ev('V36.getState().area')=='river',ev('V36.getState().area'))
  ck(sz,'guide finished at shrine',not ev('V36.guideStatus().active'))
  try: page.wait_for_function('document.querySelector(".modal h2")?.textContent.includes("旧祠")',timeout=2000)
  except BrowserTimeout: pass
  ck(sz,'shrine interaction opened', '旧祠' in (page.locator('#v27-modalhost .modal h2').first.text_content() if page.locator('#v27-modalhost .modal h2').count() else ''))
  ck(sz,'no automatic shrine purchase',ev('V36.getState().riverQuestStage')==0)
  ev('''()=>{document.querySelector('[data-do="close"]')?.click()}''')
  # NPC quest from farm should travel to village and stop on talk
  ev('''()=>{let s=V36.getState();s.area='farm';s.x=6;s.y=3;s.trackedQuest='npc:moyu';V36.debugState(s)}''')
  ck(sz,'npc route starts',ev('V36.guideTarget()') is True)
  try:page.wait_for_function('V36.getState().area==="village" && !V36.guideStatus().active',timeout=20000)
  except BrowserTimeout: print('DEBUG npc:',sz,ev('({state:V36.getState(),guide:V36.guideStatus(),modal:document.querySelector(".modal h2")?.textContent})'))
  ck(sz,'farm->village npc guide',ev('V36.getState().area')=='village')
  ck(sz,'NPC route terminates',not ev('V36.guideStatus().active'))
  ck(sz,'NPC talk triggered',page.locator('#v27-modalhost .modal').count()==1, page.locator('#v27-modalhost .modal h2').all_text_contents())
  ev('''()=>{document.querySelector('[data-do="close"]')?.click()}''')
  # Running a tracked route can be cancelled before making any transition
  ev('''()=>{let s=V36.getState();s.area='house';s.x=5;s.y=5;s.trackedQuest='river';V36.debugState(s)}''')
  ev('V36.guideTarget()');ck(sz,'manual cancel enabled',ev('V36.guideTarget()') is False)
  ck(sz,'manual cancel stopped route',not ev('V36.guideStatus().active'))
  ev('V36.guideTarget()');ev('V36.clickTile(5,4)')
  ck(sz,'manual map click cancels',not ev('V36.guideStatus().active'))
  # blocked localStorage may not alter authoritative game position
  ev('''()=>{let s=V36.getState();s.area='farm';s.x=6;s.y=3;s.trackedQuest='river';V36.debugState(s)}''')
  prev=ev('V36.getState()');ev('''()=>{window.__denyWrites=true;V36.guideTarget()}''')
  page.wait_for_timeout(1000)
  ck(sz,'blocked storage halts guide',not ev('V36.guideStatus().active'))
  ck(sz,'storage error does not move',ev('V36.getState().x')==prev['x'] and ev('V36.getState().y')==prev['y'])
  ev('window.__denyWrites=false')
  ck(sz,'no browser errors',not errors,errors)
  context.close()
 browser.close()
print('V36 RESULTS',sum(x['pass'] for x in checks),'/',len(checks))
(ROOT/'tests/v36_smoke_checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf8')
if not all(c['pass'] for c in checks):sys.exit(1)
