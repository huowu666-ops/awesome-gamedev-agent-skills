from pathlib import Path
import json,sys
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/'index.html').read_text(encoding='utf8')
BOOT='''() => {const data=new Map();window.__testSaves=data;window.__denyWrites=false;Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>data.get(k)||null,setItem:(k,v)=>{if(window.__denyWrites)throw Error('MOCK_QUOTA');data.set(k,String(v))},removeItem:k=>data.delete(k),clear:()=>data.clear()}})}'''
checks=[]
def ck(size,name,ok,detail=''):
 good=bool(ok)
 checks.append(dict(size=size,check=name,passed=good,detail='' if good else str(detail)[:320]))
 if not good:print('FAIL',size,name,detail,flush=True)
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for w,h in [(390,844),(375,667),(320,640)]:
  ctx=browser.new_context(viewport={'width':w,'height':h},is_mobile=True,has_touch=True)
  page=ctx.new_page();errors=[];page.on('pageerror',lambda e: errors.append(str(e)))
  page.evaluate(BOOT);page.set_content(HTML,wait_until='domcontentloaded',timeout=60000)
  page.evaluate('V37.open()');ev=page.evaluate;size=f'{w}x{h}'
  ck(size,'V27–V37 aliases preserved',ev('V37===V36&&V37===V35&&V37===V34&&V37===V27'))
  ck(size,'legacy WZ27 format',ev('V37.saveCode().startsWith("WZ27:")&&V37.getState().v===27'))
  ck(size,'save UI still present',page.locator('#v35-save-health').count()==1)
  ck(size,'navigation still present',page.locator('#v36-guide-status').count()==1)
  ck(size,'daily schedule button',page.locator('[data-do="v37Schedule"]').count()>=1)
  ck(size,'viewport fits',ev('document.querySelector("#v27-app").scrollWidth<=innerWidth+5'))
  ck(size,'runtime config audit',ev('V37.audit().passed===V37.audit().total'))
  ck(size,'NPC phase dawn',ev('V37.npcPhase()')==0)
  ck(size,'morning pharmacist in farm',ev('V37.npcVisitAreas(V37.data.NPC.find(n=>n.id==="shennong")).includes("farm")'))
  ck(size,'evening fox not yet at river',not ev('V37.npcVisitAreas(V37.data.NPC.find(n=>n.id==="qingwu")).includes("river")'))
  old=ev('V37.saveCode()')
  page.locator('[data-do="v37Schedule"]').first.click()
  ck(size,'diary opens five NPCs',page.locator('.v37-person').count()==5)
  ck(size,'diary location included', '九曜灵圃' in page.locator('.v37-person').nth(1).inner_text())
  ck(size,'diary read-only',ev('V37.saveCode()')==old)
  ck(size,'follow buttons 44px touch',all(x>=43 for x in page.locator('.v37-person button').evaluate_all('(nodes)=>nodes.map(n=>n.getBoundingClientRect().height)')))
  if w==390: page.screenshot(path=str(ROOT/'previews/wz_v37_schedule.png'),animations='disabled')
  page.locator('[data-do="v37Follow:moyu"]').click()
  ck(size,'follow sets tracked NPC',ev('V37.getState().trackedQuest')=='npc:moyu')
  ck(size,'follow initiates V36 route',ev('V37.guideStatus().active'))
  ev('V37.guideTarget()')
  ck(size,'follow may be cancelled',not ev('V37.guideStatus().active'))
  # At midday, the farm visitor changes; this is a derived view, never a saved NPC state.
  ev('''()=>{const s=V37.getState();s.area='village';s.x=6;s.y=5;s.minute=900;s.trackedQuest='main';V37.debugState(s)}''')
  ck(size,'afternoon phase',ev('V37.npcPhase()')==1)
  ck(size,'morning farm visitor not mislabeled at noon',not ev('V37.npcVisitAreas(V37.data.NPC.find(n=>n.id==="shennong")).includes("farm")'))
  ck(size,'river fisher at noon',ev('V37.npcVisitAreas(V37.data.NPC.find(n=>n.id==="yuchi")).includes("river")'))
  # Relationship feedback, stage and weather: no reward or consumption on repeated talk.
  ev('''()=>{let s=V37.getState();s.day=13;s.minute=1210;s.area='village';s.fav.moyu=42;s.storyStages.moyu=4;s.talkToday.moyu=true;const p=V37.npcPos(V37.data.NPC.find(n=>n.id==='moyu'));s.x=p[0]-1;s.y=p[1];V37.debugState(s)}''')
  prev=ev('V37.getState()')
  ev('V37.speak("moyu")')
  ck(size,'NPC conversation opens',page.locator('#v27-modalhost .modal').count()==1)
  feedback=page.locator('.v37-talk-feedback').all_text_contents()
  ck(size,'relationship feedback shown',len(feedback)==1 and '两章旧事' in feedback[0],feedback)
  ck(size,'weather feedback shown',len(feedback)==1 and '雷雨' in feedback[0],feedback)
  ck(size,'conversation does not grant extra reward',ev('V37.getState().gold')==prev['gold'] and ev('V37.getState().fav.moyu')==prev['fav']['moyu'])
  ev('''()=>{document.querySelector('#v27-modalhost [data-do="close"]')?.click()}''')
  ev('''()=>{let s=V37.getState();s.minute=1200;V37.debugState(s)}''')
  ck(size,'night fox includes river and farm',ev('V37.npcVisitAreas(V37.data.NPC.find(n=>n.id==="qingwu")).includes("farm")&&V37.npcVisitAreas(V37.data.NPC.find(n=>n.id==="qingwu")).includes("river")'))
  ck(size,'no browser exceptions',not errors,errors)
  ctx.close()
 browser.close()
(ROOT/'tests/v37_checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf8')
print('V37 RESULTS',sum(c['passed'] for c in checks),'/',len(checks),flush=True)
if not all(c['passed'] for c in checks):sys.exit(1)
