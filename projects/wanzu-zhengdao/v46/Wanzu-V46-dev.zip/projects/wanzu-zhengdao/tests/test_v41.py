from playwright.sync_api import sync_playwright
from pathlib import Path
root = Path(__file__).resolve().parents[1]
with sync_playwright() as pw:
    browser = pw.chromium.launch(executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    page = browser.new_page(viewport={'width':320,'height':640}, has_touch=True)
    page.goto((root/'index.html').as_uri())
    page.evaluate('V41.open()')
    for i, day in enumerate([1,8,15,22]):
        page.evaluate('(day)=>{let s=V41.getState();s.day=day; V41.debugState(s)}',day)
        page.locator('[data-do="riverLetters"]').click()
        buttons = page.locator('[data-do^="riverReply:"]')
        assert buttons.count()==2
        if i:
            assert '上封回音' in page.locator('#v27-modalhost').inner_text()
        buttons.nth(i%2).click()
        assert buttons.count()==0
        page.locator('#v27-modalhost [data-do="close"]').click()
    page.reload()
    assert page.evaluate('V41.getState().riverChoices')==[1,2,1,2]
    browser.close()
print('Four seasonal choices and save reload passed.')
