from pathlib import Path
import json,sys
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/'index.html').read_text(encoding='utf8')
BOOT='''() => {const m=new Map();window.__denyWrites=false;Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>m.get(k)||null,setItem:(k,v)=>{if(window.__denyWrites)throw Error('QUOTA');m.set(k,String(v))},removeItem:k=>m.delete(k),clear:()=>m.clear()}})}'''
checks=[]
def ck(sz,name,ok):
 checks.append(dict(size=sz,check=name,passed=bool(ok)))
 if not ok:print('FAIL',sz,name,flush=True)
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for w,h in [(390,844),(375,667),(320,640)]:
  c=b.new_context(viewport={'width':w,'height':h},is_mobile=True,has_touch=True);q=c.new_page();errors=[];q.on('pageerror',lambda e:errors.append(str(e)))
  q.evaluate(BOOT);q.set_content(HTML,wait_until='domcontentloaded',timeout=60000);ev=q.evaluate;ev('V38.open()');sz=f'{w}x{h}'
  ev('''()=>{const s=V38.getState();s.area='house';s.x=5;s.y=5;s.minute=660;s.trackedQuest='river';V38.debugState(s)}''')
  ck(sz,'house route first exit',ev('V38.guideStep().nextArea')=='farm')
  ck(sz,'house route starts',ev('V38.guideTarget()') is True)
  ck(sz,'guide active',ev('V38.guideStatus().active'))
  ck(sz,'manual cancel',ev('V38.guideTarget()') is False)
  ck(sz,'manual route clears',not ev('V38.guideStatus().active'))
  ev('''()=>{const s=V38.getState();s.area='farm';s.x=6;s.y=3;s.trackedQuest='river';V38.debugState(s)}''')
  ck(sz,'farm route targets town',ev('V38.guideStep().nextArea')=='village')
  ev('''()=>{const s=V38.getState();s.area='village';s.x=6;s.y=5;V38.debugState(s)}''')
  ck(sz,'village route targets river',ev('V38.guideStep().nextArea')=='river')
  ev('''()=>{const s=V38.getState();s.area='river';s.x=2;s.y=4;V38.debugState(s)}''')
  ck(sz,'river route ends at shrine',ev('V38.guideStep().label')=='河神旧祠')
  ev('''()=>{const s=V38.getState();s.area='house';s.x=5;s.y=5;s.trackedQuest='river';V38.debugState(s)}''')
  old=ev('V38.getState()')
  ev('window.__denyWrites=true')
  # Guide planning is in-memory until first move; a denied write must not move anything
  ev('V38.guideTarget()');ev('V38.guideTarget()')
  ck(sz,'no movement while writes blocked',ev('V38.getState().x')==old['x'] and ev('V38.getState().area')==old['area'])
  ck(sz,'no browser errors',not errors)
  c.close()
 b.close()
(ROOT/'tests/v38_route_checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
print('V38 ROUTE SPOT',sum(x['passed'] for x in checks),'/',len(checks),flush=True)
if not all(x['passed'] for x in checks):sys.exit(1)
