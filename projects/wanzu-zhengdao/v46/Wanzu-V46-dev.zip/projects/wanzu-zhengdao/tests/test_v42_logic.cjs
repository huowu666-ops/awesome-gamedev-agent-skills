const fs=require('node:fs'), vm=require('node:vm'), assert=require('node:assert/strict');
const js=fs.readFileSync(__dirname+'/../source/V42_ferry.js','utf8');
const env={ctx:{save(){},restore(){},translate(){},fillRect(){this.n++},n:0},T:64,SEASONS:['春','夏','秋','冬'],seasonOf:()=>'春',state:{day:1,riverChoices:[0,0,0,0]},makeButton:(name,id)=>'<button data-do="'+id+'">'+name+'</button>'};
vm.runInNewContext(js,env);
const endings=new Set();
for(let mask=0;mask<16;mask++){
 const choices=Array.from({length:4},(_,i)=>1+((mask>>i)&1));
 endings.add(env.ferryAfterword(choices));
}
assert.equal(endings.size,16);
assert.equal(env.ferryAfterword([1,2,0,2]),'');
for(const pick of [1,2]){env.ctx.n=0;env.drawFerryModel(7,4,pick);assert.ok(env.ctx.n>50)}
assert.equal(env.ferryTools(false).split('<details')[0].match(/<button/g).length,3);
assert.match(env.ferryTools(false),/本季来信/);
env.state.riverChoices[0]=1;
assert.match(env.ferryTools(false),/本季回信/);
console.log('PASS: 16 distinct endings, incomplete story, both models, primary tools and letter status');
