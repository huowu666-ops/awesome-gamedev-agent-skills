from pathlib import Path
from playwright.sync_api import sync_playwright
import json

ROOT=Path(__file__).resolve().parents[1]
checks=[]
HTML=(ROOT/'index.html').read_text(encoding='utf8')
# This browser harness blocks file:// and 127.0.0.1 navigations. Isolate the game
# in about:blank; replace storage APIs with deterministic mocks. This is NOT a
# substitute for testing real Safari IndexedDB persistence.
BOOT=r'''() => {
 const data=new Map(),v39IdbData=new Map(); window.__v39TestStorage=data;
 window.__denyWrites=false;
 Object.defineProperty(window,'localStorage',{configurable:true,value:{
  getItem:k=>data.get(k)||null,
  setItem:(k,v)=>{if(window.__denyWrites)throw Error('QUOTA_SIM');data.set(k,String(v))},
  removeItem:k=>data.delete(k),clear:()=>data.clear()
 }});
 const database={
  objectStoreNames:{contains:()=>true},createObjectStore:()=>{},close:()=>{},
  transaction:()=>{const tx={oncomplete:null,onerror:null,onabort:null,
   objectStore:()=>({
    put(v,k){v39IdbData.set(k,structuredClone(v));setTimeout(()=>tx.oncomplete?.(),0)},
    get(k){const r={result:null,onsuccess:null,onerror:null};setTimeout(()=>{r.result=v39IdbData.get(k)||null;r.onsuccess?.()},0);return r}
   })};return tx}
 };
 Object.defineProperty(window,'indexedDB',{configurable:true,value:{
  open(name,version){const req={result:null,onupgradeneeded:null,onsuccess:null,onerror:null};setTimeout(()=>{req.result=database;req.onupgradeneeded?.();req.onsuccess?.()},0);return req}
 }});
}'''
def ck(screen,title,cond,detail=''):
 good=bool(cond);checks.append({'viewport':screen,'check':title,'passed':good,'detail':detail if not good else ''})
 if not good:print('FAIL',screen,title,detail,flush=True)

try:
 with sync_playwright() as p:
  browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  for w,h in [(390,844),(375,667),(320,640)]:
   ctx=browser.new_context(viewport={'width':w,'height':h},is_mobile=True,has_touch=True,accept_downloads=True)
   page=ctx.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
   page.evaluate(BOOT);page.set_content(HTML,wait_until='domcontentloaded',timeout=60000)
   page.evaluate('V39.open()')
   s=f'{w}x{h}';ev=page.evaluate
   ck(s,'V27–V39 aliases',ev('V39===V38 && V39===V37 && V39===V36 && V39===V35 && V39===V27'))
   ck(s,'WZ27 save format',ev('V39.saveCode().startsWith("WZ27:")'))
   ck(s,'no horizontal overflow',ev('document.querySelector("#v27-app").scrollWidth<=innerWidth+5'))
   ck(s,'v39 toolbar button',page.locator('[data-do="v39Panel"]').count()==1)
   ck(s,'v35 snapshots retained',page.locator('#v35-save-health').count()==1)
   ck(s,'v36 route tracker retained',page.locator('#v36-guide-status').count()==1)
   ck(s,'v37 NPC schedule retained',page.locator('[data-do="v37Schedule"]').count()==1)
   ck(s,'v38 street board retained',page.locator('[data-do="v38Street"]').count()==1)
   ck(s,'audit pass',ev('V39.audit().passed===V39.audit().total'),str(ev('V39.audit()')))
   # A* shortest-path monotonic Manhattan: each step is cardinal and in-bounds
   pth=ev('V39.pathTo(3,4)')
   cur=ev('({x:V39.getState().x,y:V39.getState().y})')
   valid=all(abs((cur['x'] if i==0 else pth[i-1][0])-x)+abs((cur['y'] if i==0 else pth[i-1][1])-y)==1 for i,(x,y) in enumerate(pth))
   ck(s,'A* returns cardinal path',bool(pth) and valid,str(pth))
   st=ev('V39.v39PathStats()')
   ck(s,'A* records stats',st.get('algorithm')=='A* · TinyQueue' and st.get('steps')==len(pth) and st.get('expanded',0)>0)
   ck(s,'A* unreachable/outside returns empty',ev('V39.pathTo(-1,-1).length')==0)
   # Panel and save to IDB. A backup is saved off authoritative localStorage.
   page.locator('[data-do="v39Panel"]').first.click()
   ck(s,'vault panel rendered',page.locator('#v39-vault-status').count()==1)
   if w==390:
    (ROOT/'previews').mkdir(exist_ok=True)
    page.screenshot(path=str(ROOT/'previews/v39_open_source_vault.png'),full_page=False)
   ck(s,'touch-friendly actions',ev('''()=>[...document.querySelectorAll('.v39-vault-actions button')].every(x=>x.getBoundingClientRect().height>=44)'''))
   ck(s,'vault initially empty',ev('''async()=>{const p=await V39.v39MirrorStatus();return p.available&&!p.hasBackup}'''))
   ck(s,'manual IDB mirror succeeds',ev('''async()=>{const a=V39.getState();await V39.v39WriteMirror(a);const b=await V39.v39ReadMirror();return b&&b.data.day===a.day&&b.data.gold===a.gold}'''))
   ck(s,'mirror reports metadata',ev('''async()=>{const d=await V39.v39MirrorStatus();return d.available&&d.hasBackup&&d.day===1}'''))
   # mutate canonical game state; mirror must not overwrite it by itself
   ck(s,'older backup does not auto-restore',ev('''async()=>{const st=V39.getState();st.gold=173;V39.debugState(st);const b=await V39.v39ReadMirror();return V39.getState().gold===173&&b.data.gold===180}'''))
   # auto mirror is queued only after successful commit; don't wait 5 seconds per device
   ck(s,'storage write failure preserves game state',ev('''()=>{const b=V39.getState().gold;window.__denyWrites=true;let threw=false;try{const s=V39.getState();s.gold=9;V39.debugState(s)}catch(e){threw=true}finally{window.__denyWrites=false}return threw&&V39.getState().gold===b}'''))
   # restoring from IDB first must create a localStorage V35 restore point
   ck(s,'verified IDB restore and snapshot',ev('''async()=>{await V39.v39RestoreConfirm();return V39.getState().gold===180&&V39.restorePoints().some(p=>p.gold===173)}'''))
   ck(s,'checksum detects corrupted mirror',ev('''async()=>{const db=await new Promise((resolve,reject)=>{const r=indexedDB.open('wanzu_v39_offline_vault');r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)});await new Promise((res,rej)=>{const tx=db.transaction('saves','readwrite');const get=tx.objectStore('saves').get('latest');get.onsuccess=()=>{const d=get.result;d.raw='{"tampered":true}';tx.objectStore('saves').put(d,'latest')};tx.oncomplete=res;tx.onerror=()=>rej(tx.error)});db.close();try{await V39.v39ReadMirror();return false}catch(e){return /校验/.test(String(e.message))}}'''))
   ck(s,'no page errors',not errors,str(errors[:3]))
   ctx.close()
  browser.close()
finally:pass
passed=sum(1 for x in checks if x['passed'])
output=ROOT/'tests/v39_checks.json';output.write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf8')
print('V39',passed,'/',len(checks),'checks. File:',output,flush=True)
if passed!=len(checks):raise SystemExit(1)
