// Deterministic A* correctness test following Agent Skills game-ai guidance.
// Extract the production queue + pathTo() unmodified, use a grid-only sandbox.
const fs=require('fs');
const vm=require('vm');
const assert=require('assert');
const code=fs.readFileSync(__dirname+'/../source/V39_pixel_module.js','utf8');
const a=code.indexOf('class TinyQueue {'),b=code.indexOf('// V39: A* shortest-path search.'),c=code.indexOf('function clickTile(',b);
assert(a>0&&b>a&&c>b,'missing source markers');
const library=code.slice(a,b)+code.slice(b,c);
let seed=0x1234abcd;function rand(){seed ^=seed<<13;seed ^=seed>>>17;seed ^=seed<<5;return(seed>>>0)/4294967296}
const ctx={state:{x:1,y:1},canStep:null,isTargetTile:()=>false,console};
const api=vm.runInNewContext(library+'\n({pathTo,last:()=>v39LastPath})',ctx,{timeout:1000});
function bfs(grid,start,target){
 const w=grid[0].length,h=grid.length;
 const can=(x,y)=>x>=0&&y>=0&&x<w&&y<h&&!grid[y][x];
 const goals=[];if(!can(...target))for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){
  const x=target[0]+dx,y=target[1]+dy;if(can(x,y))goals.push(`${x},${y}`);
 }else goals.push(target.join(','));
 const goal=new Set(goals),q=[[...start]],dist=new Map([[start.join(','),0]]);
 while(q.length){const [x,y]=q.shift(),k=`${x},${y}`,d=dist.get(k);
  if(goal.has(k))return d;
  for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){
   const nx=x+dx,ny=y+dy,n=`${nx},${ny}`;
   if(!can(nx,ny)||dist.has(n))continue;dist.set(n,d+1);q.push([nx,ny]);
  }
 }
 return null;
}
function test(w,h){
 const grid=Array.from({length:h},()=>Array.from({length:w},()=>rand()<.21));
 const start=[Math.floor(rand()*w),Math.floor(rand()*h)],target=[Math.floor(rand()*w),Math.floor(rand()*h)];
 grid[start[1]][start[0]]=false;
 const can=(x,y)=>x>=0&&y>=0&&x<w&&y<h&&!grid[y][x];
 ctx.state.x=start[0];ctx.state.y=start[1];ctx.canStep=can;
 const path=api.pathTo(...target),b=bfs(grid,start,target);
 assert.strictEqual(path.length,b===null?0:b,`nonoptimal path ${w}x${h} from ${start} to ${target}, expected ${b}, got ${path.length}`);
 for(let i=0;i<path.length;i++){
  const [x,y]=path[i],prev=i?path[i-1]:start;
  assert(can(x,y),`path crossed a wall at ${x},${y}`);
  assert.equal(Math.abs(x-prev[0])+Math.abs(y-prev[1]),1,'non-cardinal move');
 }
 return true;
}
let n=0;for(let i=0;i<120;i++){test(12,8);n++}
for(let i=0;i<80;i++){test(40,40);n++}
console.log(`PASS: ${n}/${n} deterministic randomized A* vs BFS path length cases (12x8 and 40x40)`);
