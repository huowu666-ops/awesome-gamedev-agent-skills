from pathlib import Path
import json,sys
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/'index.html').read_text(encoding='utf8')
BOOT='''() => {const data=new Map();window.__v38Store=data;window.__denyWrites=false;Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>data.get(k)||null,setItem:(k,v)=>{if(window.__denyWrites)throw Error('SIMULATED_QUOTA');data.set(k,String(v))},removeItem:k=>data.delete(k),clear:()=>data.clear()}})}'''
checks=[]
def ck(sz,label,test,detail=''):
 ok=bool(test);checks.append(dict(size=sz,check=label,passed=ok,detail='' if ok else str(detail)[:240]))
 if not ok:print('FAIL',sz,label,detail,flush=True)

def configure(ev,day=1,trust=0,gold=180,extras=''):
 return ev(f'''()=>{{const s=V38.getState();s.mode='farm';s.area='village';s.x=6;s.y=5;s.day={day};s.minute=840;s.townTrust={trust};s.townEventDate=0;s.fairAidDay=0;s.townLedger=[];s.gold={gold};s.goods.dewleaf=5;s.goods.moonorchid=5;s.goods.goldblossom=5;s.fish=5;s.wood=10;{extras};V38.debugState(s)}}''')

with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for w,h in [(390,844),(375,667),(320,640)]:
  ctx=browser.new_context(viewport={'width':w,'height':h},is_mobile=True,has_touch=True,accept_downloads=True)
  page=ctx.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.evaluate(BOOT);page.set_content(HTML,wait_until='domcontentloaded',timeout=60000)
  page.evaluate('V38.open()');ev=page.evaluate;sz=f'{w}x{h}'
  ck(sz,'aliases V27-V38 remain equal',ev('V38===V37 && V38===V36 && V38===V35 && V38===V34 && V38===V27'))
  ck(sz,'legacy WZ27 save',ev('V38.saveCode().startsWith("WZ27:") && V38.getState().v===27'))
  ck(sz,'save center retained',page.locator('#v35-save-health').count()==1)
  ck(sz,'route guide retained',page.locator('#v36-guide-status').count()==1)
  ck(sz,'V37 schedule retained',page.locator('[data-do="v37Schedule"]').count()>=1)
  ck(sz,'V38 street button visible',page.locator('[data-do="v38Street"]').count()>=1)
  ck(sz,'fits mobile viewport',ev('document.querySelector("#v27-app").scrollWidth<=innerWidth+5'))
  ck(sz,'audit no regressions',ev('V38.audit().passed===V38.audit().total'),ev('V38.audit()'))
  ck(sz,'V38 defaults validated',ev('V38.getState().townTrust===0 && V38.getState().townLedger.length===0'))
  before=ev('V38.saveCode()');page.locator('[data-do="v38Street"]').first.click()
  ck(sz,'read-only board at farm',ev('V38.saveCode()')==before)
  ck(sz,'board disables actions away from village',page.locator('.v38-actions button:not([disabled])').count()==0)
  ck(sz,'street cards present',page.locator('.v38-street-card').count()==2)
  # import existing V37 payload that has no V38 fields
  ck(sz,'old V37 state migrates safely',ev('''()=>{const s=V38.getState();delete s.townTrust;delete s.townEventDate;delete s.fairAidDay;delete s.townLedger;V38.debugState(s);return V38.getState().townTrust===0&&V38.getState().townEventDate===0&&Array.isArray(V38.getState().townLedger)}'''))
  # test first day gift contribution, not twice
  configure(ev,day=1);before=ev('V38.getState()');p0=ev('V38.townDailyProfile()')
  ck(sz,'daily lead is fox',p0['npc']=='qingwu')
  ck(sz,'gift action persisted',ev('V38.v38ResolveDaily("gift")') is True)
  after=ev('V38.getState()')
  ck(sz,'daily gift consumes once',after['goods']['moonorchid']==before['goods']['moonorchid']-1)
  ck(sz,'daily gift increases favor/trust',after['townTrust']==before['townTrust']+4 and after['fav']['qingwu']==before['fav']['qingwu']+6)
  ck(sz,'daily log saved',len(after['townLedger'])==1 and after['townLedger'][0]['choice']=='gift')
  ck(sz,'repeat gift rejected',ev('V38.v38ResolveDaily("gift")') is False)
  ck(sz,'repeat leaves balance unchanged',ev('V38.getState().goods.moonorchid')==after['goods']['moonorchid'])
  ck(sz,'ledger survives save codec',ev('''()=>{const s=V38.getState();V38.debugState(s);return V38.getState().townLedger.length===1&&V38.getState().townTrust===4}'''))
  # no-cost dialogue gives only small favor/trust, no farm points
  configure(ev,day=2);before=ev('V38.getState()')
  ck(sz,'daily event varies by day',ev('V38.townDailyProfile().npc')=='shennong')
  ck(sz,'listen action succeeds',ev('V38.v38ResolveDaily("listen")') is True)
  after=ev('V38.getState()')
  ck(sz,'listen has no gold or score gain',after['gold']==before['gold'] and after['farmScore']==before['farmScore'])
  ck(sz,'listen increases trust once',after['townTrust']==before['townTrust']+1)
  # failed storage must not mutate memory or mark event complete
  configure(ev,day=3);before=ev('V38.getState()')
  ev('window.__denyWrites=true')
  ck(sz,'denied storage refuses event',ev('V38.v38ResolveDaily("fund")') is False)
  after=ev('V38.getState()')
  ck(sz,'failed save rolls back cost and progress',after['gold']==before['gold'] and after['townTrust']==before['townTrust'] and after['townEventDate']==before['townEventDate'])
  ev('window.__denyWrites=false')
  ck(sz,'retry succeeds after storage recovers',ev('V38.v38ResolveDaily("fund")') is True)
  # spring fair day7, one-time, original festival separate
  configure(ev,day=7);f=ev('V38.v38Fair()');before=ev('V38.getState()')
  ck(sz,'spring 7th day',f['title'].startswith('春') and f['item']=='dewleaf')
  ev('V38.v38StreetBoard()')
  ck(sz,'festival options enabled',page.locator('.v38-actions button:not([disabled])').count()>=2)
  ck(sz,'fair materials donated',ev('V38.v38ResolveFair("goods")') is True)
  after=ev('V38.getState()')
  ck(sz,'fair resource cost exact',after['goods']['dewleaf']==before['goods']['dewleaf']-2)
  ck(sz,'fair trust and relation reward',after['townTrust']==before['townTrust']+6 and after['fav']['shennong']==before['fav']['shennong']+5)
  ck(sz,'fair aid record persisted',after['fairAidDay']==7 and any(q['type']=='fair' for q in after['townLedger']))
  ck(sz,'fair second claim blocked',ev('V38.v38ResolveFair("gold")') is False)
  ck(sz,'fair duplicate no gold lost',ev('V38.getState().gold')==after['gold'])
  ev('V38.festival()')
  ck(sz,'legacy festival still available',page.locator('#v27-modalhost [data-do="claimFestival"]').count()==1)
  ev('V38.claimFestival()')
  ck(sz,'legacy festival reward independent',ev('V38.getState().festivalDate')==7)
  ck(sz,'legacy festival cannot be claimed again',ev('''()=>{const s=V38.getState();V38.claimFestival();return V38.getState().gold===s.gold&&V38.getState().farmScore===s.farmScore}'''))
  # 4 fair types as days progress
  for day,title in [(14,'夏'),(21,'秋'),(28,'冬')]:
   configure(ev,day=day)
   ck(sz,f'{title} fair selection',ev('V38.v38Fair().title').startswith(title))
   ck(sz,f'{title} fair works',ev('V38.v38ResolveFair("goods")') is True)
  # town standing affects NPC dialogue
  configure(ev,day=31,trust=35)
  ck(sz,'town reputation changes NPC remarks','街坊声望已远播' in ev('V38.npcDailyHint(V38.data.NPC[1]).relation'))
  ev('V38.v38StreetBoard()')
  ck(sz,'touch action buttons >=44px',all(n>=43 for n in page.locator('.v38-actions button').evaluate_all('(a)=>a.map(x=>x.getBoundingClientRect().height)')))
  ck(sz,'malicious townLedger data sanitized',ev('''()=>{const s=V38.getState();s.townLedger=[{day:s.day,type:'daily',choice:'INVALID',npc:'moyu',evil:'x'},{day:s.day+1,type:'fair',choice:'gold',npc:'moyu'},{day:s.day,type:'fair',choice:'gold',npc:'moyu',evil:'x'}];V38.debugState(s);return V38.getState().townLedger.length===1&&V38.getState().townLedger[0].evil===undefined}'''))
  ck(sz,'no JS runtime exceptions',len(errors)==0,errors)
  if w==390:
   page.screenshot(path=str(ROOT/'previews/wz_v38_street_board.png'),animations='disabled',full_page=False)
  ctx.close()
 browser.close()
(ROOT/'tests/v38_checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf8')
print('V38 RESULTS',sum(c['passed'] for c in checks),'/',len(checks),flush=True)
if not all(c['passed'] for c in checks):sys.exit(1)
