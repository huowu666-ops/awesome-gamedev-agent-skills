from pathlib import Path
from playwright.sync_api import sync_playwright
import json
ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/'index.html').read_text(encoding='utf-8')
checks=[]
BOOT='''() => { const db=new Map(); window.__denyWrites=false;Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>db.get(k)||null,setItem:(k,v)=>{if(window.__denyWrites)throw Error('QUOTA_SIM');db.set(k,String(v))},removeItem:k=>db.delete(k),clear:()=>db.clear()}});}'''
def ck(screen,title,condition,detail=''):
 result=bool(condition);checks.append({'viewport':screen,'check':title,'passed':result,'detail':str(detail)[:250] if not result else ''})
 if not result:print('FAIL:',screen,title,detail,flush=True)
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for w,h in [(390,844),(375,667),(320,640)]:
  page=browser.new_page(viewport={'width':w,'height':h},is_mobile=True,has_touch=True)
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.evaluate(BOOT);page.set_content(HTML,wait_until='domcontentloaded',timeout=60000)
  ev=page.evaluate;s=f'{w}x{h}'
  ev('V40.open()')
  ck(s,'legacy API aliases',ev('V40===V39&&V39===V38&&V40===V27'))
  ck(s,'WZ27 save marker',ev('V40.saveCode().startsWith("WZ27:")'))
  ck(s,'no horizontal overflow',ev('document.querySelector("#v27-app").scrollWidth<=innerWidth+5'))
  ck(s,'V38 street retained',page.locator('[data-do="v38Street"]').count()==1)
  ck(s,'V39 vault retained',page.locator('[data-do="v39Panel"]').count()==1)
  ck(s,'V40 hearts accessible',page.locator('[data-do="v40Hearts"]').count()==1)
  ck(s,'V40 sound accessible',page.locator('[data-do="v40Sounds"]').count()==1)
  ck(s,'FSM rain shelters',ev('''()=>{const n=V40.data.NPC[1],s=V40.getState();s.day=3;s.minute=540;return V40.v40NpcMind(n,s).mode==='shelter'}'''))
  ck(s,'FSM evening rests',ev('''()=>{const n=V40.data.NPC[1],s=V40.getState();s.day=3;s.minute=1200;return V40.v40NpcMind(n,s).mode==='rest'}'''))
  ck(s,'FSM friendly social afternoon',ev('''()=>{const n=V40.data.NPC[1],s=V40.getState();s.day=1;s.minute=780;s.fav.shennong=18;return V40.v40NpcMind(n,s).mode==='social'}'''))
  ck(s,'FSM invalid event safe',ev('V40.v40Transition("work","unknown")==="work"'))
  ev('''()=>{const st=V40.getState();st.area='farm';st.x=2;st.y=4;st.day=1;st.minute=540;V40.debugState(st)}''')
  page.locator('[data-do="v40Hearts"]').first.click()
  ck(s,'five NPC cards',page.locator('.v40-person').count()==5)
  ck(s,'touch targets >=44px',ev('''()=>[...document.querySelectorAll('.v40-buttons button')].every(el=>el.getBoundingClientRect().height>=44)'''))
  ck(s,'shennong nearby enabled',not page.locator('[data-do="v40Care:shennong"]').is_disabled())
  ck(s,'remote qingwu disabled',page.locator('[data-do="v40Care:qingwu"]').is_disabled())
  if w==390:
   (ROOT/'previews').mkdir(exist_ok=True)
   page.screenshot(path=str(ROOT/'previews/v40_hearts.png'))
  page.locator('[data-do="v40Care:shennong"]').click()
  ck(s,'greeting rewards fav and trust',ev('''()=>{const s=V40.getState();return s.fav.shennong===2&&s.townTrust===1&&s.npcCareDay.shennong===1}'''))
  ck(s,'greeting written to note',ev('V40.getState().notes.at(-1).includes("沈禾")'))
  ck(s,'repeat prevented',ev('V40.v40Care("shennong")===false'))
  ck(s,'repeat unchanged',ev('V40.getState().fav.shennong===2'))
  ck(s,'old save migrates care fields',ev('''()=>{const s=V40.getState();delete s.npcCareDay;V40.debugState(s);return Object.keys(V40.getState().npcCareDay).length===5}'''))
  ck(s,'storage failure rolls back',ev('''()=>{const s=V40.getState();s.npcCareDay.shennong=0;V40.debugState(s);const before=V40.getState();window.__denyWrites=true;const ret=V40.v40Care('shennong');window.__denyWrites=false;const after=V40.getState();return !ret&&after.fav.shennong===before.fav.shennong&&after.townTrust===before.townTrust&&after.npcCareDay.shennong===before.npcCareDay.shennong}'''))
  page.locator('[data-do="v40Sounds"]').first.click()
  ck(s,'sound panel rendered',page.locator('.v40-sound-buttons button').count()==3)
  ck(s,'defaults silent',ev('localStorage.getItem("wanzu_v40_audio_enabled")===null'))
  page.locator('[data-do="v40SoundEnable"]').first.click()
  ck(s,'user gesture enables sound',ev('localStorage.getItem("wanzu_v40_audio_enabled")==="1"'))
  page.locator('[data-do="v40SoundDisable"]').first.click()
  ck(s,'mute persists',ev('localStorage.getItem("wanzu_v40_audio_enabled")==="0"'))
  ck(s,'no runtime errors',not errors,errors[:3])
  page.close()
 browser.close()
out=ROOT/'tests/v40_checks.json';out.write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
passed=sum(x['passed'] for x in checks)
print('V40:',passed,'/',len(checks),'browser checks; report',out,flush=True)
if passed!=len(checks):raise SystemExit(1)
