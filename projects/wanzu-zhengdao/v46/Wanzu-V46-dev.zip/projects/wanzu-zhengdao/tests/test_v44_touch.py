from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
with sync_playwright() as pw:
    browser=pw.chromium.launch(args=['--no-sandbox'])
    for width,height,choice,action,result in [(320,640,'铸一口渡雾钟','敲钟接船','晨雾里的第二条船'),(390,844,'做一盏桥头灯','举灯照亮石阶','桥头开了早市')]:
        page=browser.new_page(viewport={'width':width,'height':height},has_touch=True)
        errors=[]
        page.on('pageerror',lambda e:errors.append(str(e)))
        page.goto((root/'index.html').as_uri())
        panel=page.locator('#night44')
        def tap(label):
            panel.get_by_role('button',name=label,exact=True).tap()
        for label in ['开始游戏','走到桥头','帮铁柏引船',choice]:tap(label)
        page.reload()
        tap('继续游戏')
        tap(action)
        assert '船靠岸了'==panel.locator('h1').inner_text()
        tap('留到翌晨')
        assert panel.locator('h1').inner_text()==result
        assert panel.evaluate('(e)=>e.scrollWidth<=innerWidth+1')
        tap('去洞府，开始自由修行')
        assert not panel.is_visible()
        assert page.locator('#v27-app').is_visible()
        assert page.evaluate('V44.saveCode().startsWith("WZ27:")')
        assert not errors,errors
        page.close()
    browser.close()
print('PASS both branches, reload, dialogue, narrow screens and main-game handoff')
