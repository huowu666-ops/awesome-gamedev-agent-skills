# 《万族争道 V40 · 百业心境》

原生 HTML + CSS + Canvas 2D 单机像素仙侠生活 RPG。**打开 `index.html` 即可游玩**，不需 GitHub/npm/模拟器，不要求联网。

## 新增（在 V39 基础上）

- 百业心境：五位 NPC 的当值/闲谈/避雨/歇息状态；在靠近角色时每天可问候一次。
- 山海声景：可开关原创合成提示音，iPhone 必须点击启用才尝试启动 AudioContext。
- 原有 V39 A*、离线备份、V38 四时街闻、V36 跨区路引、V35 快照仍保留。

操作：进入像素洞府 → 工具栏「百业心境」/「山海声景」。建议先到灵圃沈禾附近测试「当面问候」，再打开「存档卷宗」导出 WZ27 备份。

构建：`python scripts/build_v40.py`。
检查：`python scripts/verify_v39.py`、`python tests/test_v40.py`、`python tests/test_v39.py` 等（需要 Python Playwright 和 Chromium）。

完整项目引用与许可证计划见 `docs/V40_OPEN_SOURCE_ROADMAP.md`。V40 已经是**本地构建版本，不代表 GitHub 已经推送**。实际 iPhone 存档和音频仍需真机测试。

---

# 《万族争道 V39 · 开源增强》

适用于 iPhone 等触屏设备的**原生 HTML / Canvas 2D 单机修仙生活 + 战斗 + CRPG** 游戏。单文件 `index.html` 可以离线运行，无需服务器、CDN 或外部图片资源。V39 在 V38 基础上新增 A* + TinyQueue 寻路、IndexedDB 独立存档镜像、手机「开源工匣」入口。

**游戏是独立原创作品；第三方 TinyQueue 采用 ISC 许可证，不意味着游戏整体开放源代码授权。** 详情见 `GAME_CONTENT_NOTICE.md`、`third_party/tinyqueue/LICENSE`。

## V39 运行方式

- 打开 `index.html`，进入「四时山居 · 开源增强 V39」。
- 在像素洞府工具栏点击「开源工匣」，可检查路线、备份至独立保险库、恢复或下载 TXT 存档。
- 保险库需要浏览器允许 IndexedDB；如文件预览或隐私模式不允许使用，旧自动存档仍可运行，请主动下载 TXT 到 iPhone「文件」。
- 存档格式：保留 `WZ27:` 及 `wanzu_v27_pixel_sanctuary`，不做不可逆迁移。

## 构建与检查

```bash
python scripts/build_v39.py
python scripts/verify_v39.py
python tests/test_v39.py          # Playwright Chromium，模拟 IndexedDB 接口
node tests/test_v39_astar.js       # 200 个随机网格 A* 与 BFS 最短路对照
python tests/test_v38.py
python tests/test_v37.py
python tests/test_v35.py
python tests/test_v34.py
python tests/test_v38_route_regression.py
```

## 开源项目审查和限制

- `docs/V39_OPEN_SOURCE_REVIEW.md`：候选 GitHub 项目、许可证和实际集成情况
- `docs/V39_QA_REPORT.md`：本轮测试结果与未验证项
- `docs/OPEN_SOURCE_PRIORITY_LIST.md`：后续持续改良路线
- GitHub 推荐路径：`projects/wanzu-zhengdao/`，请勿覆盖仓库根目录原有 Agent Skills 文件。

---

## V38 历史玩法

**原创单机修仙生活 / 战斗 / CRPG 浏览器游戏**。下载 `index.html` 后可在支持本地 HTML 的浏览器中离线运行，无需服务器或 CDN。游戏引擎为原生 HTML + CSS + JavaScript + Canvas 2D（不是 Godot、Phaser 或 Unity）。

## V38 更新

- **每日街闻**：万族小镇每天有一则依日期、天气、NPC 关系和人物支线变化的街坊事件。可赠送指定物资、支付 18 灵石、或免费倾听；同一游戏日只结算一次，回馈人物好感和街坊声望。
- **四时协作**：每七日一次的季末集会额外开放季节协作任务，春·药灯、夏·溪畔、秋·赤炉、冬·青丘，各自有物资与灵石两种援助方式；每季只结算一次，独立于旧版集会奖励。
- **镇民关系**：新增街坊声望（0–100）及最近 16 条有限记录。较高声望会反馈到 V37 人物对话氛围里。原人物支线没有被改写或重置。
- **旧档兼容**：新增 `townTrust`、`townEventDate`、`fairAidDay`、`townLedger` 四个字段，统一经 `fresh()` / `validated()` 校验。旧版 `WZ27:` 和 `wanzu_v27_pixel_sanctuary` 均保留。
- **存储安全**：所有物资、灵石和好感奖励均通过原有 write-before-swap 的 `change()` 事务完成，模拟浏览器存储失败时不扣款、不领取。

## 游玩提示

进入像素山居，前往 **万族小镇**，点击工具栏中的 **「四时街闻」**。可在任意地图查看信息，但须在小镇里才能参与。每第 7、14、21、28… 个游戏日能参与对应季末协作；原有四时集会也保留。

V35 存档中心、V36 自动跨区引路、V37 五族日程簿，以及旧版灵田、河岸、双商铺、秘境和文字 CRPG 继续保留。

## 可复现构建和测试

```bash
python scripts/build_v38.py
python scripts/verify_v38.py
python tests/test_v38.py                  # 需 Python Playwright + Chromium
python tests/test_v38_route_regression.py # 快速寻路边界测试
python tests/test_v37.py                 # 旧版本回归
python tests/test_v35.py
python tests/test_v34.py
```

仓库推荐目标路径：`projects/wanzu-zhengdao/`。**不要覆盖仓库根目录 `skills/`、`router/` 等已有 Agent Skills 文件**。

原始浏览器脚本及可重现构建文件位于 `source/` 和 `scripts/`。`baseline/V37.html` 用于重建 V38；它保留于开发包，不是另外一套运行时依赖。

## 发布与测试限制

本地已进行 Chromium 模拟移动屏幕测试，但尚未验证真实 iPhone Safari 长期存档，也未把本版本确认提交到 GitHub。原仓库 Apache-2.0 技能库的许可与本游戏的原创内容授权是两个独立事项，详情见 `GAME_CONTENT_NOTICE.md`。
