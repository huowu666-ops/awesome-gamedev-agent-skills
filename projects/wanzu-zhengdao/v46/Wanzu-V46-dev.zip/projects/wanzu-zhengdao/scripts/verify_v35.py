from pathlib import Path
from html.parser import HTMLParser
import subprocess,tempfile,re
ROOT=Path(__file__).resolve().parents[1]
html=(ROOT/'index.html').read_text(encoding='utf-8')
assert '<html' in html and '</html>' in html and 'window.V35=' in html
for marker in ['WZ27:','wanzu_v27_pixel_sanctuary','wanzu_v27_manual_backup','wanzu_v35_restore_points','v35-save-health','v35-import-file','safeReplaceSave','createRestorePoint']:
 assert marker in html,marker
class S(HTMLParser):
 def __init__(self):super().__init__();self.active=False;self.blocks=[]
 def handle_starttag(self,tag,attrs):
  if tag=='script':
   a=dict(attrs);self.active=not a.get('src') and a.get('type','text/javascript') in ('text/javascript','module')
   if self.active:self.blocks.append('')
 def handle_endtag(self,tag):
  if tag=='script':self.active=False
 def handle_data(self,data):
  if self.active:self.blocks[-1]+=data
parser=S();parser.feed(html)
assert len(parser.blocks)>=20
with tempfile.TemporaryDirectory() as p:
 for i,b in enumerate(parser.blocks):
  file=Path(p)/(str(i)+'.js')
  file.write_text(b,encoding='utf-8')
  q=subprocess.run(['node','--check',str(file)],capture_output=True,text=True)
  assert q.returncode==0,f'script {i}: {q.stderr}'
print('PASS: V35',len(parser.blocks),'JavaScript inline blocks; compatibility markers')
