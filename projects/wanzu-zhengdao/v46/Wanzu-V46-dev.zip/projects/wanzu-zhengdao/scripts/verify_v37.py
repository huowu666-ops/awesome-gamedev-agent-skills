from pathlib import Path
from html.parser import HTMLParser
import subprocess,tempfile
root=Path(__file__).resolve().parents[1]
html=(root/'index.html').read_text(encoding='utf8')
for marker in ['window.V37=window.V36=','wanzu_v27_pixel_sanctuary','wanzu_v35_restore_points','v36-guide-status','v37-schedule-list','function npcScheduleBook','function npcDailyHint','WZ27:']:
 assert marker in html,marker
class Scripts(HTMLParser):
 def __init__(self):super().__init__();self.active=False;self.blocks=[]
 def handle_starttag(self,tag,attrs):
  if tag=='script':
   a=dict(attrs);self.active=not a.get('src') and a.get('type','text/javascript') in ('text/javascript','module')
   if self.active:self.blocks.append('')
 def handle_endtag(self,tag):
  if tag=='script':self.active=False
 def handle_data(self,data):
  if self.active and self.blocks:self.blocks[-1]+=data
parse=Scripts();parse.feed(html);assert len(parse.blocks)>=20,len(parse.blocks)
with tempfile.TemporaryDirectory() as d:
 for i,content in enumerate(parse.blocks):
  file=Path(d)/f'{i}.js';file.write_text(content,encoding='utf8')
  result=subprocess.run(['node','--check',str(file)],capture_output=True,text=True)
  assert result.returncode==0,f'script {i}: {result.stderr}'
print('PASS',len(parse.blocks),'inline JS blocks; V37 NPC diary and V36 / V35 compatibility markers')
