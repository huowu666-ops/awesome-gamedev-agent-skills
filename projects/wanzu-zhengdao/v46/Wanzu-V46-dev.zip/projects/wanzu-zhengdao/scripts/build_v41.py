from pathlib import Path
root = Path(__file__).resolve().parents[1]
html = (root/'baseline/V40.html').read_text()
def replace(old, new):
    global html
    assert html.count(old) == 1, old
    html = html.replace(old, new)
replace('function v40HeartBook(){', (root/'source/V41_river_letters.js').read_text()+'\nfunction v40HeartBook(){')
replace('npcCareDay:{},meals:', 'npcCareDay:{},riverChoices:[0,0,0,0],meals:')
replace(' a.npcCareDay=', ' a.riverChoices=riverLetters.map((_,i)=>[1,2].includes(x.riverChoices?.[i])?x.riverChoices[i]:0);\n a.npcCareDay=')
# validated() may run during initial state load, before the story table is initialized.
html=html.replace('a.riverChoices=riverLetters.map','a.riverChoices=[0,0,0,0].map')
replace("makeButton('百业心境','v40Hearts')", "makeButton('渡口来信','riverLetters')+makeButton('百业心境','v40Hearts')")
replace(" if(action==='v40Hearts')", """ if(action==='riverLetters')return riverLetterBook();
 const reply=/^riverReply:([0-3]):([12])$/.exec(action);
 if(reply)return replyRiverLetter(Number(reply[1]),Number(reply[2]));
 if(action==='v40Hearts')""")
replace('window.V40=window.V39=', 'window.V41=window.V40=window.V39=')
html=html.replace('V40 百业心境','V41 渡口来信').replace('百业心境 V40','渡口来信 V41').replace('V40 · 百业心境','V41 · 渡口来信')
(root/'index.html').write_text(html)
