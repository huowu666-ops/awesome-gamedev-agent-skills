from pathlib import Path
from html.parser import HTMLParser
import subprocess,tempfile,hashlib
ROOT=Path(__file__).resolve().parents[1]
html=(ROOT/'index.html').read_text(encoding='utf8')
source=(ROOT/'source/V39_pixel_module.js').read_text(encoding='utf8')
assert 'window.V39=window.V38=' in html
assert 'function pathTo(tx,ty)' in source and 'class TinyQueue' in source
assert 'function v39ReadMirror()' in source and 'function v39StoragePanel()' in source
assert 'wanzu_v27_pixel_sanctuary' in source and 'WZ27:' in source
assert 'Copyright (c) 2017, Vladimir Agafonkin' in html
assert 'Permission to use, copy, modify, and/or distribute' in html
assert 'ISC License' in (ROOT/'third_party/tinyqueue/LICENSE').read_text()
class Parser(HTMLParser):
 def __init__(self): super().__init__();self.scripts=[];self.inside=False
 def handle_starttag(self,tag,attrs):
  attrs=dict(attrs)
  if tag=='script' and not attrs.get('src') and attrs.get('type','text/javascript') in ('text/javascript','module'):
   self.scripts.append('');self.inside=True
 def handle_endtag(self,tag):
  if tag=='script':self.inside=False
 def handle_data(self,data):
  if self.inside and self.scripts:self.scripts[-1]+=data
p=Parser();p.feed(html)
assert len(p.scripts)==28,len(p.scripts)
with tempfile.TemporaryDirectory() as tmp:
 for i,code in enumerate(p.scripts):
  f=Path(tmp)/'module.js';f.write_text(code,encoding='utf8')
  v=subprocess.run(['node','--check',str(f)],capture_output=True,text=True)
  if v.returncode:raise SystemExit(f'JS block {i}: {v.stderr}')
print('PASS V39: 28 inline JavaScript syntax checks, legacy save marker and TinyQueue ISC notice')
