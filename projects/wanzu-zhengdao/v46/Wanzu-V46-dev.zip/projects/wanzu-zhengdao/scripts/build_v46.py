from pathlib import Path

root = Path(__file__).resolve().parents[1]
page = (root / 'baseline/V45.html').read_text()

def replace(before, after):
    global page
    assert page.count(before) == 1, before
    page = page.replace(before, after)

replace('const fresh=()=>({v:27', """const ferryStages = ['start','shore','forge','bell','lamp','bell-home','lamp-home','bell-dawn','lamp-dawn'];
function legacyFerryStage(){
 try {
  const stage = localStorage.getItem('wanzu_ferry_prologue_v1');
  if (ferryStages.includes(stage)) return stage;
 } catch {}
 return 'start';
}
const fresh=()=>({ferryStage:'start',v:27""")
replace(' a.riverChoices=', """ a.ferryStage = ferryStages.includes(x.ferryStage) ? x.ferryStage :
  (Object.hasOwn(x,'ferryStage') ? 'start' : legacyFerryStage());
 a.riverChoices=""")
replace('getSaved(MANUAL)||fresh(),root=', "getSaved(MANUAL)||{...fresh(),ferryStage:legacyFerryStage()},root=")
replace('window.V45=window.V44', 'window.V46=window.V45=window.V44')
replace('transfer,riverInteract,riverForage,', """setFerryStage(stage){
  if (!ferryStages.includes(stage)) return false;
  return change(draft=>{draft.ferryStage=stage},{quiet:true});
 },transfer,riverInteract,riverForage,""")
begin = page.index(" const key='wanzu_ferry_prologue_v1',allowed=")
end = page.index(' const nodes={',begin)
page = page[:begin] + """ let scene=window.V46.getState().ferryStage,entered=false,frame=0,last=0,audio;
 function save(next){
  if (!window.V46.setFerryStage(next)){
   status.textContent='浏览器没有保存这一步。请允许本地存储后重试。';
   return false;
  }
  scene=next;
  status.textContent='';
  return true;
 }
""" + page[end:]
replace('支持 V27 至 V36 的 WZ27 存档码，也可从 iPhone', '支持历代 WZ27 存档码。V46 起会一并恢复渡口剧情。也可从 iPhone')
(root / 'index.html').write_text(page)
