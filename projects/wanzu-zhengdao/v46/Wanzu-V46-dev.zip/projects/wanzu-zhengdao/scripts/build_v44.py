from pathlib import Path
root=Path(__file__).resolve().parents[1]
html=(root/'baseline/V43.html').read_text()
assert html.count('</body>')==1
(root/'index.html').write_text(html.replace('</body>',(root/'source/V44_night.html').read_text()+'</body>').replace('window.V43=window.V42','window.V44=window.V43=window.V42'))
