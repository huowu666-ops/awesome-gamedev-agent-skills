from pathlib import Path
import re,hashlib
ROOT=Path(__file__).resolve().parents[1]
base=(ROOT/'baseline/V34.html').read_text(encoding='utf-8')
source=(ROOT/'source/V35_pixel_module.js').read_text(encoding='utf-8')
style=(ROOT/'source/V35_mobile_style.css').read_text(encoding='utf-8')
assert base.count('</head>')==1
out=base.replace('</head>','<style id="v35-save-touch-style">'+style+'</style>\n</head>',1)
p=re.compile(r'(<script id="v27-pixel-sim-js">)(.*?)(</script>)',re.S)
m=p.search(out)
assert m
out=out[:m.start()]+m.group(1)+source+m.group(3)+out[m.end():]
out=out.replace('V34 · 山海路引 · 原创像素修仙','V35 · 存档护航 · 原创像素修仙')
path=ROOT/'index.html'
path.write_text(out,encoding='utf-8')
assert p.search(out).group(2)==source
print('PASS: V35 built reproducibly; sha256',hashlib.sha256(out.encode()).hexdigest())
