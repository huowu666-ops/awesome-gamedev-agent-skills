from pathlib import Path
from html.parser import HTMLParser
import subprocess,tempfile
ROOT=Path(__file__).resolve().parents[1]
html=(ROOT/'index.html').read_text(encoding='utf8')
for marker in ['window.V36=window.V35=','wanzu_v27_pixel_sanctuary','wanzu_v35_restore_points','v36-guide-status','function guideStep','function guideLeg','function stopGuide','WZ27:']:
 assert marker in html,marker
class Scripts(HTMLParser):
 def __init__(self):super().__init__();self.active=False;self.blocks=[]
 def handle_starttag(self,tag,attrs):
  if tag=='script':
   a=dict(attrs);self.active=not a.get('src') and a.get('type','text/javascript') in ('text/javascript','module')
   if self.active:self.blocks.append('')
 def handle_endtag(self,tag):
  if tag=='script':self.active=False
 def handle_data(self,data):
  if self.active and self.blocks:self.blocks[-1]+=data
parser=Scripts();parser.feed(html);assert len(parser.blocks)>=20,len(parser.blocks)
with tempfile.TemporaryDirectory() as tmp:
 for i,content in enumerate(parser.blocks):
  p=Path(tmp)/f'{i}.js';p.write_text(content,encoding='utf8')
  result=subprocess.run(['node','--check',str(p)],capture_output=True,text=True)
  assert result.returncode==0,f'script {i}: {result.stderr}'
print('PASS:',len(parser.blocks),'inline JS scripts, V36 route code and V35 save compatibility')
