from pathlib import Path
import re,hashlib
ROOT=Path(__file__).resolve().parents[1]
base=(ROOT/'baseline/V35.html').read_text(encoding='utf8')
source=(ROOT/'source/V36_pixel_module.js').read_text(encoding='utf8')
css=(ROOT/'source/V36_mobile_style.css').read_text(encoding='utf8')
assert base.count('</head>')==1
# Replace V35 mobile styling rather than stacking duplicate versions.
style=re.compile(r'(<style id="v35-save-touch-style">)(.*?)(</style>)',re.S)
assert len(style.findall(base))==1
out=style.sub(lambda _: '<style id="v36-touch-style">'+css+'</style>',base,count=1)
pattern=re.compile(r'(<script id="v27-pixel-sim-js">)(.*?)(</script>)',re.S)
assert len(pattern.findall(out))==1
out=pattern.sub(lambda m:m.group(1)+source+m.group(3),out,count=1)
out=out.replace('V35 · 存档护航 · 原创像素修仙','V36 · 山海自动路引 · 原创像素修仙')
path=ROOT/'index.html';path.write_text(out,encoding='utf8')
assert pattern.search(out).group(2)==source
print('V36 REBUILT sha256',hashlib.sha256(out.encode()).hexdigest())
