from pathlib import Path
root = Path(__file__).resolve().parents[1]
page = (root / 'baseline/V42.html').read_text()
def change(old, new):
    global page
    assert page.count(old) == 1, old
    page = page.replace(old, new)
change("const rows=riverLetters.map((letter,i)=>{", """const current=riverLetters.findIndex(letter=>letter.season===season);
 const cards=riverLetters.map((letter,i)=>{""")
change("""}).join('');
 modalBox('渡口来信',ferryAfterword(state.riverChoices)+'<p>每七日换季。每封信可回一次，错过的信在来年同季仍可作答。</p><div class="v40-cards">'+rows+'</div>'""","""});
 const otherCards=cards.filter((_,i)=>i!==current).join('');
 const archive='<details class="v42-more"><summary>查看其他三季书信</summary><div class="v40-cards">'+otherCards+'</div></details>';
 modalBox('渡口来信','<div class="v40-cards">'+cards[current]+'</div>'+ferryAfterword(state.riverChoices)+archive+'<p>每七日换季。错过的信可在来年同季回复。</p>'""")
# Only the toolbar disclosure controls the persistent toolbar preference.
change("e.target.matches?.('.v42-more')","e.target.matches?.('.page .v42-more')")
change('window.V42=window.V41','window.V43=window.V42=window.V41')
page=page.replace('V42 渡口人间','V43 四时信册').replace('渡口人间 V42','四时信册 V43').replace('V42 · 渡口人间','V43 · 四时信册').replace('万族争道 · 渡口人间</strong>','万族争道 · 四时信册</strong>')
(root / 'index.html').write_text(page)
