from pathlib import Path
import re,hashlib
ROOT=Path(__file__).resolve().parents[1]
base=(ROOT/'baseline/V36.html').read_text(encoding='utf8')
source=(ROOT/'source/V37_pixel_module.js').read_text(encoding='utf8')
css=(ROOT/'source/V37_mobile_style.css').read_text(encoding='utf8')
style=re.compile(r'<style id="v36-touch-style">.*?</style>',re.S)
assert len(style.findall(base))==1
out=style.sub(lambda _: '<style id="v37-touch-style">'+css+'</style>',base,count=1)
script=re.compile(r'(<script id="v27-pixel-sim-js">)(.*?)(</script>)',re.S)
assert len(script.findall(out))==1
out=script.sub(lambda m:m.group(1)+source+m.group(3),out,count=1)
out=out.replace('V36 · 山海自动路引 · 原创像素修仙','V37 · 人间烟火 · 原创像素修仙')
(ROOT/'index.html').write_text(out,encoding='utf8')
print('V37 rebuilt sha256',hashlib.sha256(out.encode()).hexdigest())
