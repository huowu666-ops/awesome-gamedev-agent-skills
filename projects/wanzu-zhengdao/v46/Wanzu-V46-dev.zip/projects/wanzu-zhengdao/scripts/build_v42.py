from pathlib import Path
root=Path(__file__).resolve().parents[1]
page=(root/'baseline/V41.html').read_text()
def replace(old,new):
    global page
    assert page.count(old)==1,old
    page=page.replace(old,new)
replace('function riverLetterBook(){',(root/'source/V42_ferry.js').read_text()+'\nfunction riverLetterBook(){')
start=page.index(" '<div class=\"toolbar\">'+(!dungeon?")
end=page.index('<div class="log" aria-live',start)
page=page[:start]+" ferryTools(dungeon)+'"+page[end:]
replace(" if(area==='river'){\n  if(y===4", " if(area==='river'){\n  if(x===7&&y===4)drawFerryModel(x,y,state.riverChoices[2]);\n  if(y===4")
replace("if(state.area==='river')return atSite(RIVER_SITES,x,y)||NPC", "if(state.area==='river')return (x===7&&y===4&&!!state.riverChoices[2])||atSite(RIVER_SITES,x,y)||NPC")
replace(" notify('灵溪流水自东而来", """ if(x===7&&y===4&&state.riverChoices[2])return riverLetterBook();
 notify('灵溪流水自东而来""")
replace("modalBox('渡口来信','<p>每七日", "modalBox('渡口来信',ferryAfterword(state.riverChoices)+'<p>每七日")
replace("root.addEventListener('change',onSaveFile);","""root.addEventListener('change',onSaveFile);
 root.addEventListener('toggle',e=>{if(e.target.matches?.('.v42-more') && root.contains(e.target))ferryMenuOpen=e.target.open},true);""")
replace('window.V41=window.V40','window.V42=window.V41=window.V40')
replace('</head>', '<style>'+ (root/'source/V42_ferry.css').read_text()+'</style></head>')
page=page.replace('V41 渡口来信','V42 渡口人间').replace('渡口来信 V41','渡口人间 V42').replace('V41 · 渡口来信','V42 · 渡口人间').replace('万族争道 · 百业心境</strong>','万族争道 · 渡口人间</strong>')
(root/'index.html').write_text(page)
