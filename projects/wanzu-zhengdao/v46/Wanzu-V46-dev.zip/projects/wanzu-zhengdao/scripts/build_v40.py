from pathlib import Path
import re, hashlib
ROOT=Path(__file__).resolve().parents[1]
base=(ROOT/'baseline/V39.html').read_text(encoding='utf-8')
source=(ROOT/'source/V40_pixel_module.js').read_text(encoding='utf-8')
css=(ROOT/'source/V40_mobile_style.css').read_text(encoding='utf-8')
style=re.compile(r'<style id="v39-touch-style">.*?</style>',re.S)
assert len(style.findall(base))==1
out=style.sub(lambda m:'<style id="v40-touch-style">'+css+'</style>',base,count=1)
script=re.compile(r'(<script id="v27-pixel-sim-js">)(.*?)(</script>)',re.S)
assert len(script.findall(out))==1
out=script.sub(lambda m:m.group(1)+source+m.group(3),out,count=1)
out=out.replace('V39 · 开源增强 · 原创像素修仙','V40 · 百业心境 · 原创像素修仙')
(ROOT/'index.html').write_text(out,encoding='utf-8')
print('V40 sha256',hashlib.sha256(out.encode()).hexdigest())
