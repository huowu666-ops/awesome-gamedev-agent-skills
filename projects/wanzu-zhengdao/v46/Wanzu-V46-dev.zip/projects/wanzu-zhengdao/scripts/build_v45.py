from pathlib import Path
root=Path(__file__).resolve().parents[1]
page=(root/'baseline/V44.html').read_text()
def replace(old,new):
    global page
    assert page.count(old)==1,old
    page=page.replace(old,new)
replace("function play(){if(window.V43?.open()){panel.hidden=true;cancelAnimationFrame(frame)}}","""const destinationKey='wanzu_v45_destination';
 let resumeFarm=false;
 try{resumeFarm=localStorage.getItem(destinationKey)==='farm'}catch{}
 function rememberDestination(value){
  resumeFarm=value==='farm';
  try{localStorage.setItem(destinationKey,value)}catch{}
 }
 function play(){
  if(window.V44?.open()){
   rememberDestination('farm');
   panel.hidden=true;
   cancelAnimationFrame(frame);
  }
 }""")
replace("const options=first?[[scene==='start'?", """if(first&&resumeFarm)line.textContent='上回已进入洞府。可以继续修行，也可以回到渡口故事。';
 panel.querySelector('#night-skip').hidden=first&&resumeFarm;
 const options=first&&resumeFarm?[['继续自由修行','play'],['回到渡口故事','enter']]:first?[[scene==='start'?""")
replace("if(next==='enter'){entered=true}","if(next==='enter'){rememberDestination('story');entered=true}")
replace('window.V44=window.V43','window.V45=window.V44=window.V43')
(root/'index.html').write_text(page)
