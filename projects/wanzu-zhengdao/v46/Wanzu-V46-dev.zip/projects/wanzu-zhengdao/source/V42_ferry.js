// Tile coordinates deliberately sit beside the bridge, clear of travel and shop triggers.
const ferryFrame = {'.':null,k:'#352e29',w:'#74543b',h:'#c59a65',g:'#82765b',a:'#eac26a',l:'#ffeabd',r:'#ae5543'};
const ferryModels = [
 ['..kk......kk..','..whkkkkkkwh..','..whhhhhhhwh..','..wh..kk..wh..','..wh.kggk.wh..','..wh.kgak.wh..','..whkggggkwh..','..whkaaaakwh..','..wh..kw..wh..','..wh..kr..wh..','.kwwk....kwwk.'],
 ['......kk......','....kkhhkk....','..kkwwwwwwkk..','....kallak....','....kallak....','....kallak....','....kkkkkk....','......ww......','......wh......','.....kwwk.....','....kwwwwk....']
];
function drawFerryModel(x,y,pick){
 const rows=ferryModels[pick-1];
 if(!rows)return;
 ctx.save();
 ctx.translate(x*T+4,y*T+12);
 ctx.fillStyle='rgba(42,43,38,.28)';
 ctx.fillRect(5,41,46,5);
 rows.forEach((row,dy)=>[...row].forEach((cell,dx)=>{
  const color=ferryFrame[cell];
  if(color){ctx.fillStyle=color;ctx.fillRect(dx*4,dy*4,4,4)}
 }));
 ctx.restore();
}
function ferryAfterword(choices){
 const [spring,summer,autumn,winter]=choices;
 if(!choices.every(Boolean))return '';
 const guest=spring===1?'卖茶婆提着去年晒的茶叶':'采药童背着一篓止血草';
 const shore=summer===1?'踏上铁柏用漂木补好的踏板':'在浅滩看见一群长大的银鱼';
 const night=autumn===1?'雾里传来一声钟响，船夫认出了岸':'桥头的灯照着缆绳，船夫伸手一捞便靠了岸';
 const line=winter===1?'墨羽指着木牌上的小字，逐个念出帮过忙的乡亲。':'一个孩子踮脚在木牌上添了小船，说这是今日到渡口的第一位客人。';
 return '<article class="v42-ending"><h3>末封 · 渡口有人</h3><p>'+guest+'，'+shore+'。'+night+'。</p><p>'+line+'</p></article>';
}
function ferryTools(dungeon){
 const index=SEASONS.indexOf(seasonOf(state.day));
 const letter=state.riverChoices[index]?'本季回信':'本季来信';
 const primary='<div class="v42-primary">'+makeButton(letter,'riverLetters')+makeButton('山河路引','worldmap')+makeButton(dungeon?'回洞府':'九曜坊市',dungeon?'retreat':'sell')+'</div>';
 const village=dungeon?'':makeButton('每日乡约','bulletin')+makeButton('五族日程簿','v37Schedule')+makeButton('四时街闻','v38Street');
 return primary+'<details class="v42-more" '+(ferryMenuOpen?'open':'')+'><summary>手记与更多工具</summary><div class="toolbar">'+village+makeButton('百业心境','v40Hearts')+makeButton('山海手记','journal')+makeButton('山海声景','v40Sounds')+makeButton('存档卷宗','saves')+makeButton('开源工匣','v39Panel')+makeButton('游玩说明','help')+'</div></details>';
}
let ferryMenuOpen=false;
