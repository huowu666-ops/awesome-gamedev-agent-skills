// Each letter stores one fixed choice for the lifetime of this village.
const riverLetters = [
 {season:'春', author:'沈禾', title:'一畦药苗', text:'旧渠只够灌一畦。沈禾把两捆秧苗放在脚边：“今年先种哪一捆？”',
  choices:['给渡口种解暑茶','给山民种止血草'], replies:['渡口多了一排矮茶树。沈禾在头一株上系了红绳。','石阶旁冒出细小的青芽。沈禾教采药童辨认叶背的白纹。']},
 {season:'夏', author:'鱼迟', title:'水涨三尺', text:'夜雨把渡口的缆桩冲歪了。鱼迟只剩一张旧网，问你该把网系在哪里。',
  choices:['在浅滩拦漂木','在桥洞救鱼苗'], replies:['天明时，网兜里攒了半船木料，铁柏挑走两根做桥桩。','鱼迟蹲了一夜，把困在桥洞里的鱼苗一瓢瓢送回深水。']},
 {season:'秋', author:'铁柏', title:'炉上余铁', text:'炉里剩的铁只够打一件东西。铁柏拿出两张沾灰的图纸，请你替他定夺。',
  choices:['打一口渡雾钟','打一盏桥头灯'], replies:['新钟挂上了槐枝。隔着秋雾，也听得清船靠岸的三声。','灯罩打成了鱼鳞纹。风从桥上穿过，火苗只轻轻一歪。']},
 {season:'冬', author:'青妩', title:'封河之夜', text:'河冰初结，青妩在坛前留了一块空木牌：“这一年的事，怎样让后来的人记住？”',
  choices:['请墨羽刻下众人姓名','留白，请过桥人续写'], replies:['墨羽数过每一个名字才肯落刀。第二年春水来时，字缝里长出青苔。','头一行是一枚歪歪的童子手印。等到雪停，木牌背面也写满了。']}
];
function riverLetterBook(){
 const season=seasonOf(state.day);
 const rows=riverLetters.map((letter,i)=>{
  const pick=state.riverChoices[i];
  let body;
  if(pick) body='<p>'+letter.choices[pick-1]+'。'+letter.replies[pick-1]+'</p>';
  else if(season===letter.season && state.mode==='farm'){
   const earlier=riverLetters[i-1], previous=state.riverChoices[i-1];
   body=(previous?'<p>上封回音 · '+earlier.replies[previous-1]+'</p>':'')+
    '<p>'+letter.text+'</p><div class="v40-buttons">'+letter.choices.map((label,j)=>makeButton(label,'riverReply:'+i+':'+(j+1))).join('')+'</div>';
  }else body='<small>可于'+letter.season+'季在洞府回信。</small>';
  return '<article class="v40-person"><b>'+letter.season+' · '+letter.title+'　'+letter.author+'</b>'+body+'</article>';
 }).join('');
 modalBox('渡口来信','<p>每七日换季。每封信可回一次，错过的信在来年同季仍可作答。</p><div class="v40-cards">'+rows+'</div>',[{label:'收起信册',on:'close'}]);
}
function replyRiverLetter(i,pick){
 const letter=riverLetters[i];
 if(!letter || ![1,2].includes(pick) || state.mode!=='farm' || seasonOf(state.day)!==letter.season || state.riverChoices[i])return false;
 const ok=change(s=>{
  s.riverChoices[i]=pick;
  s.log=letter.author+'收到了你的回信。';
  s.notes=[...s.notes.slice(-349),'第'+s.day+'日 · '+letter.title+'：'+letter.choices[pick-1]];
 });
 if(ok)riverLetterBook();
 return ok;
}
