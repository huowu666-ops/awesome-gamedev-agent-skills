# V38 协作规则（沿用 V34–V37 约定）

- 当前开发版本为 **V38 四时街闻**。`window.V27`—`window.V38` 必须保持兼容。
- V35 不改变 `WZ27:` 前缀、`v:27` 与原自动/手动存档键。
- 新增的三份恢复快照使用 `wanzu_v35_restore_points`；对任何恢复/导入/重开操作，先保护原状态，再持久化目标状态。
- 提交前运行 `python scripts/build_v38.py`、`python scripts/verify_v38.py`、`python tests/test_v38.py` 和 `python tests/test_v38_route_regression.py`；旧兼容回归 `python tests/test_v37.py`、`python tests/test_v35.py` 与 `python tests/test_v34.py`。
- 街闻事务只可在小镇成功写盘后结算，`townLedger` 必须按白名单验证，拒绝恶意或损坏字段。不要将快照或玩家 WZ27 存档码提交到公开 GitHub。

---

# 《万族争道》V34 — AI 开发协作约定

## 引擎检测
这是 **原生 HTML + CSS + JavaScript + Canvas 2D** 的自研网页游戏，单文件 `index.html` 可离线启动。**不是 Phaser / PixiJS / Godot / Unity**；禁止未经要求迁移引擎。游戏同时包含旧版文字 CRPG、原版动作试炼及 V27–V34 像素生活模块。

## 外部技能库
技能来源：你的 GitHub 仓库 `huowu666-ops/awesome-gamedev-agent-skills`；上游 `gamedev-skills/awesome-gamedev-agent-skills`，Apache-2.0。项目含安装脚本 `scripts/install-agent-skills.sh`。安装前应先审查其代码和许可证；安装需要联网和 Node.js >=22.20。

适用的技能组合：
- UI、触控、导航：`game-ui-ux` + `input-systems`
- 存档、迁移、损坏校验：`save-systems`
- NPC 巡游、寻路与碰撞：`game-ai` + `level-design`
- 像素素材统一与检验：`create-game-assets`
- 五族人物任务与对话：`dialogue-systems` + `rpg`
- 长期运行卡顿：`performance-optimization`（先测量）
- 关卡迭代：`game-docs`（只在文档任务中使用）

所有技能只提供**设计与检查流程**。不要假定本自研 Canvas 引擎存在其它引擎的 API。

## 不可破坏的约束
1. 保留 `window.V27`–`window.V34` 兼容调用；不覆盖旧版文字游戏全局 `S`、`SAVE_KEY`、`FT`。
2. 继续接受 `WZ27:` 存档码和 `wanzu_v27_pixel_sanctuary` 键。新字段必须加入 `fresh()` 与 `validated()`，白名单校验。
3. 所有付费、奖励、任务阶段更新须通过写盘成功后才交换状态的 `change()` 事务；失败时不得扣款或给奖励。
4. 种田与战斗可独立毕业（各自条件）；不会强制其中一条依赖另一条。
5. 图片保持最近邻像素缩放，无外部 HTTP 运行依赖。尽量保留 32×32 人物、64×64 地图瓦片、16×16 图标规范。
6. 主要交互测试覆盖 320×640、375×667、390×844；检查横向溢出、目标可触达、键盘／触控、存档导入和 `localStorage` 故障。
7. 禁止在 GitHub issue / 日志中上传玩家的完整存档码或账户凭据。

## 构建与检查
```bash
python scripts/build_v34.py
python scripts/verify.py
```
可选的浏览器专项测试：在有 Python Playwright + Chromium 的环境运行 `python tests/test_v34.py`。不具有这些依赖时不能将其称为“已跑通过”。

## 版本推进
新内容按“源码评审 → 修复 → 单元/模拟测试 → 触控回归 → 日志总结”的顺序。新版本必须说明已完成与未完成事项，切忌用夸张的测试断言替代实体 iPhone Safari 验证。

## 同仓库公开协作
- 你已明确同意将游戏与 Agent Skills 放在同一个公开仓库中。本项目专属目录为 `projects/wanzu-zhengdao/`，绝不覆盖技能库根目录与已有文件。
- 游戏新增工作流使用独立命名的 `.github/workflows/wanzu-v36-verify.yml`，不要覆盖上游同名工作流。
- 原有玩家存档码、口令、令牌和私密数据不得提交。
- GitHub 集成目前读取可用，但文件写入和创建分支均被 403 拒绝；请不要误称已提交。

## V36 注意事项
- 路引状态仅存在于内存，不能加入 WZ27 存档；到达交互目标后停止自动导航。
- 引路时行走、过区仍必须通过成功写盘的原有 change()/transfer()。

## V37 补充要求
- `npcVisitAreas` 是根据既有 NPC 在不同区域的出现条件派生的视图，不能单独写成另一个影响实体可见性的存档状态。
- 对话气氛采用函数按需生成，不能改变人物赠礼次数、委托奖励与存档事务。
- 发布前运行 `scripts/build_v37.py`、`scripts/verify_v37.py` 与三个旧版浏览器测试。

## V39 开源合规
V39 引入 TinyQueue (ISC)；保留第三方版权许可。IndexedDB 为原创实现，借鉴 idb-keyval 公开架构，不取代 WZ27 写盘事务。不得在未审查许可证时合并其他项目素材。

## V40 追加准则
- 新 NPC 心境仅作为行为表现层，禁止无测试更改 V31 的 NPC 巡游坐标或 V36 跨区自动寻路；奖励必须经 `change()` 写盘后返回成功。
- `npcCareDay` 为新的白名单存档字段；不能删除 V27 `WZ27` 兼容性。
- 山海声景是用户点击开启的原创 Web Audio 音效；禁止自动播放、外部音源请求或将开关放进 WZ27 存档。
- 先跑 `python tests/test_v40.py` 和旧版回归，再记录结果。外部项目与许可证见 `docs/V40_OPEN_SOURCE_ROADMAP.md`。
