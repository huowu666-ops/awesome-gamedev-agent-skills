from pathlib import Path
from playwright.sync_api import sync_playwright

root = Path(__file__).resolve().parents[1]
with sync_playwright() as pw:
    browser = pw.chromium.launch()
    for filename, repaired in [('baseline/V47.html',False), ('index.html',True)]:
        for width, height in [(320,640),(375,667),(390,844)]:
            page = browser.new_page(viewport={'width':width,'height':height},has_touch=True,offline=True)
            page.goto((root / filename).as_uri(),wait_until='commit')
            page.wait_for_function('Boolean(window.V47)')
            page.get_by_role('button',name='进入自由修行',exact=True).tap()
            for stage, title in [('bell-dawn','渡口试声'),('lamp-home','灯下候船')]:
                page.evaluate("""stage=>{
                    const s=V47.getState();
                    Object.assign(s,{area:'river',tool:'hand',day:15,x:6,y:4,face:'right',ferryStage:stage});
                    V47.debugState(s);
                }""",stage)
                page.get_by_role('button',name='交互',exact=True).tap()
                modal=page.locator('#v27-modalhost')
                if repaired:
                    assert title in modal.inner_text()
                    modal.get_by_role('button',name='离开桥头').tap()
                else:
                    assert title not in modal.inner_text()
            if repaired:
                for face,title in [('left','灯下候船'),('down','烟波茶摊')]:
                    page.evaluate("""face=>{const s=V47.getState();Object.assign(s,{x:8,y:4,face});V47.debugState(s)}""",face)
                    page.get_by_role('button',name='交互',exact=True).tap()
                    assert title in modal.inner_text()
                    modal.locator('button[data-do="close"]').tap()
            page.close()
    browser.close()
print('PASS V47 reproduction and V48 touch-button repair, bell, lamp and adjacent stall')
